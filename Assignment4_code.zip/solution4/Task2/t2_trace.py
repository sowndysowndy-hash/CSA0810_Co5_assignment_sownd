"""Task 2.4 - trace of the processing for one small file that contains a damaged line."""
from t2_attendance import InvalidRecord, parse_line

lines = ["192311001,2026-10-01,P", "192311002,2026-10-01,A", "192311003,2026-10-01", "192311001,2026-10-01,P"]
present, total = {}, {}
print(f"{'line':<5}{'content':<26}{'action':<40}present / total")
for number, line in enumerate(lines, start=1):
    try:
        regno, date, status = parse_line(line)
        total[regno] = total.get(regno, 0) + 1
        if status == "P":
            present[regno] = present.get(regno, 0) + 1
        action = f"count {status} for {regno[-3:]}"
    except InvalidRecord as err:
        action = f"damaged: {err}"
    print(f"{number:<5}{line:<26}{action:<40}{present} / {total}")
