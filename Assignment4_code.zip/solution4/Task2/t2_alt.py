"""Alternative concept: re-read all daily files once per student  versus  read every file once."""
import json
import tempfile
import time
from pathlib import Path

from t2_attendance import parse_line, process_month


def make(folder, s, f):
    for d in range(f):
        lines = [f"{192300000 + i},2026-10-{d + 1:02d},{'P' if (i + d) % 4 else 'A'}" for i in range(s)]
        (Path(folder) / f"day{d:02d}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def per_student(folder, s):
    result = {}
    for i in range(s):                                       # one pass over ALL files for each student
        regno, p, t = str(192300000 + i), 0, 0
        for path in sorted(Path(folder).glob("*.txt")):
            with path.open(encoding="utf-8") as fh:
                for line in fh:
                    r, d, st = parse_line(line)
                    if r == regno:
                        t += 1
                        p += st == "P"
        result[regno] = (p, t)
    return result


res = []
print(f"{'s':>5}{'f':>4}{'l (=s)':>8}{'re-read per student (s)':>26}{'read once (s)':>16}{'ratio':>8}  same")
for s in (25, 50, 100, 200):
    f = 20
    with tempfile.TemporaryDirectory() as tmp:
        make(tmp, s, f)
        t0 = time.perf_counter(); a = per_student(tmp, s); t_re = time.perf_counter() - t0
        t0 = time.perf_counter(); present, total, _ = process_month(tmp); t_once = time.perf_counter() - t0
        b = {r: (present.get(r, 0), total[r]) for r in total}
    print(f"{s:>5}{f:>4}{s:>8}{t_re:>26.4f}{t_once:>16.4f}{t_re / t_once:>8.0f}x  {a == b}")
    res.append({"s": s, "f": f, "l": s, "reread_s": t_re, "once_s": t_once, "same": a == b})
json.dump(res, open("t2_alt_results.json", "w"), indent=1)
