"""Task 2 - monthly attendance processor: reads every daily file once and accumulates counts in dictionaries."""
from pathlib import Path


class InvalidRecord(Exception):
    """A line is not 'regno,date,P|A'."""


def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    regno, date, status = (p.strip() for p in parts)
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status {status!r}")
    return regno, date, status


def process_month(folder):
    present, total, damaged = {}, {}, []
    for path in sorted(Path(folder).glob("*.txt")):             # the daily files, in date order
        with path.open(encoding="utf-8") as f:                  # mode "r": we only read
            for number, line in enumerate(f, start=1):
                if not line.strip():
                    continue                                    # blank lines are ignored
                try:
                    regno, date, status = parse_line(line)
                except InvalidRecord as err:
                    damaged.append((path.name, number, str(err)))
                    continue
                total[regno] = total.get(regno, 0) + 1
                if status == "P":
                    present[regno] = present.get(regno, 0) + 1
    return present, total, damaged


def write_reports(present, total, damaged, threshold=75.0):
    low = []
    with open("attendance_summary.csv", "w", encoding="utf-8") as out:       # mode "w": new report each run
        out.write("regno,present,recorded,percentage\n")
        for regno in sorted(total):
            pct = 100 * present.get(regno, 0) / total[regno]
            out.write(f"{regno},{present.get(regno, 0)},{total[regno]},{pct:.1f}\n")
            if pct < threshold:
                low.append((regno, pct))
    with open("below75.txt", "w", encoding="utf-8") as out:
        for regno, pct in low:
            out.write(f"{regno} {pct:.1f}%\n")
    with open("damaged.log", "w", encoding="utf-8") as out:
        for name, number, message in damaged:
            out.write(f"{name} line {number}: {message}\n")


if __name__ == "__main__":
    present, total, damaged = process_month("att_oct")
    write_reports(present, total, damaged)
    for name in ("attendance_summary.csv", "below75.txt", "damaged.log"):
        print(f"--- {name}")
        print(open(name, encoding="utf-8").read().rstrip("\n"))
