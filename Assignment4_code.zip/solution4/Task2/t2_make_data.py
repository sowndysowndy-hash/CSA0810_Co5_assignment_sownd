"""Creates the sample biometric files for October 2026 (one text file per day: regno,date,P/A)."""
from pathlib import Path

folder = Path("att_oct")
folder.mkdir(exist_ok=True)
students = ["192311001", "192311002", "192311003", "192311004", "192311005", "192311006"]
# status of each student on each of the 5 days (P = present, A = absent)
status = {
    "192311001": "PPPPP",
    "192311002": "PPAPP",
    "192311003": "PAAPA",
    "192311004": "AAPAP",
    "192311005": "PPPAP",
    "192311006": "PPPPA",
}
for d in range(5):
    date = f"2026-10-0{d + 1}"
    lines = [f"{s},{date},{status[s][d]}" for s in students]
    if d == 2:
        lines[2] = "192311003," + date                 # damaged: status missing
    if d == 3:
        lines[3] = f"192311004,{date},X"              # damaged: wrong status letter
        lines.insert(2, "")                             # blank line in the middle of the file
    (folder / f"{date}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("Created", len(list(folder.glob('*.txt'))), "files in", folder)
for p in sorted(folder.glob("*.txt")):
    print("\n--", p.name)
    print(p.read_text(encoding="utf-8").rstrip("\n"))
