"""Task 1.2 - repaired mess-bill totaller."""
from decimal import Decimal, InvalidOperation


def total_bills(filename):
    """Return (total, report_lines, rejected) for a file of 'regno,name,amount' lines."""
    total = Decimal("0.00")
    report, rejected = [], []
    try:
        with open(filename, encoding="utf-8") as f:       # closed automatically
            for number, line in enumerate(f, start=1):     # one line in memory at a time
                line = line.strip()
                if not line:                               # ignore blank lines
                    continue
                parts = line.split(",")
                if len(parts) != 3:
                    rejected.append((number, line, f"expected 3 fields, found {len(parts)}"))
                    continue
                try:
                    amount = Decimal(parts[2])             # exact money, paise allowed
                except InvalidOperation:
                    rejected.append((number, line, f"amount {parts[2]!r} is not a number"))
                    continue
                total += amount
                report.append(f"{parts[1]} {amount}")
    except FileNotFoundError:
        rejected.append((0, filename, "file not found"))
    except PermissionError:
        rejected.append((0, filename, "permission denied"))
    return total, report, rejected


for name in ("mess_oct.txt", "mess_nov.txt"):
    total, report, rejected = total_bills(name)
    print("File:", name)
    print("\n".join(report))
    print("Total", total)
    print("Rejected:", len(rejected))
    for item in rejected:
        print("  ", item)
    print()
