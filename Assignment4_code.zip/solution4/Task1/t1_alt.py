"""Alternative concept: f.read() / f.readlines() versus iterating over the file (50,000 lines)."""
import json
import os
import time
import tracemalloc

NAME = "mess_50000.txt"
with open(NAME, "w", encoding="utf-8") as f:
    for i in range(50000):
        f.write(f"{192300000 + i},Student{i},{1000 + i % 500}.{i % 100:02d}\n")
size = os.path.getsize(NAME)


def by_iteration():
    total = 0.0
    with open(NAME, encoding="utf-8") as f:
        for line in f:
            total += float(line.split(",")[2])
    return total


def by_read():
    with open(NAME, encoding="utf-8") as f:
        data = f.read()
    return sum(float(line.split(",")[2]) for line in data.split("\n") if line)


def by_readlines():
    with open(NAME, encoding="utf-8") as f:
        lines = f.readlines()
    return sum(float(line.split(",")[2]) for line in lines)


res = {"file_bytes": size}
print(f"File size: {size:,} bytes, 50,000 lines")
print(f"{'method':<22}{'time (s)':>10}{'peak memory (KB)':>20}  total")
for label, fn in (("iterate line by line", by_iteration), ("f.read()", by_read), ("f.readlines()", by_readlines)):
    best = 1e9
    for _ in range(3):
        t0 = time.perf_counter()
        r = fn()
        best = min(best, time.perf_counter() - t0)
    tracemalloc.start()
    fn()
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    print(f"{label:<22}{best:>10.4f}{peak / 1024:>20,.0f}  {r:,.2f}")
    res[label] = {"time_s": best, "peak_kb": peak / 1024}
json.dump(res, open("t1_alt_results.json", "w"), indent=1)
os.remove(NAME)
