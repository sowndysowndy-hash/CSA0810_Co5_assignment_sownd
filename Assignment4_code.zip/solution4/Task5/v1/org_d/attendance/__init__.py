"""(d) The attendance package."""
