from pathlib import Path

import reader
import report
import stats


def main(folder="att5"):
    out = Path(__file__).resolve().parent
    records, damaged = reader.read_month(folder)
    table = stats.percentages(records)
    report.write_summary(table, out / "summary.csv")
    report.write_damaged(damaged, out / "damaged.log")
    print("below 75%:", stats.below(table))
    print("damaged lines:", len(damaged))


if __name__ == "__main__":
    main()
