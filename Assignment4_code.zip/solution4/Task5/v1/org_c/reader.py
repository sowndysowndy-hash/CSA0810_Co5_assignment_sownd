"""(c) reading daily files."""
from pathlib import Path


class InvalidRecord(Exception):
    """A line is not 'regno,date,P|A'."""


def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    regno, date, status = (p.strip() for p in parts)
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status {status!r}")
    return regno, date, status


def read_month(folder):
    """Return (records, damaged) for every daily file in the folder."""
    records, damaged = [], []
    for path in sorted(Path(folder).glob("*.txt")):
        with path.open(encoding="utf-8") as f:
            for number, line in enumerate(f, start=1):
                if not line.strip():
                    continue
                try:
                    regno, date, status = parse_line(line)
                except InvalidRecord as err:
                    damaged.append((path.name, number, str(err)))
                    continue
                records.append((date, regno, status))
    return records, damaged
