"""Sample daily files for Task 5: 6 students, 6 days; student 004 is absent on three consecutive days."""
from pathlib import Path

folder = Path("att5")
folder.mkdir(exist_ok=True)
students = ["192311001", "192311002", "192311003", "192311004", "192311005", "192311006"]
status = {"192311001": "PPPPPP", "192311002": "PPAPPP", "192311003": "PAPPAP",
          "192311004": "AAAPPA", "192311005": "PPPAPP", "192311006": "PPPPAA"}
for d in range(6):
    date = f"2026-10-0{d + 1}"
    lines = [f"{s},{date},{status[s][d]}" for s in students]
    if d == 2:
        lines[1] = f"192311002,{date}"                    # damaged line
    (folder / f"{date}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("created", len(list(folder.glob("*.txt"))), "daily files in", folder)
