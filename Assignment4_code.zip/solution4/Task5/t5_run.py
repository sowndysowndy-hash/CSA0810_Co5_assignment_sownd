"""Runs the 8 programs (4 organisations x 2 versions), compares their output files and counts the files changed."""
import filecmp
import subprocess
import sys
from pathlib import Path

MAIN = {"a": "attendance_a.py", "b": "main_b.py", "c": "main_c.py", "d": "main_d.py"}
for v in (1, 2):
    print(f"=== version {v}")
    outs = {}
    for org, script in MAIN.items():
        d = Path(f"v{v}/org_{org}")
        # the data folder is given relative to the organisation's folder
        r = subprocess.run([sys.executable, "-c", f"import runpy,sys; sys.argv=['{script}']; "
                            f"m = runpy.run_path('{script}', run_name='not_main'); m['main']('../../att5')"],
                           cwd=d, capture_output=True, text=True)
        outs[org] = (r.stdout, (d / "summary.csv").read_text(), (d / "damaged.log").read_text(),
                     (d / "streaks.txt").read_text() if v == 2 else "")
        print(f"org ({org}) exit {r.returncode}: {r.stdout.strip().splitlines()}")
        if r.returncode:
            print(r.stderr)
    print("all four organisations give identical output files:", len({str(o[1:]) for o in outs.values()}) == 1)
    print("summary.csv:\n" + outs["a"][1].rstrip())
    if v == 2:
        print("streaks.txt:", outs["a"][3].split())


def changed(org):
    files, added = [], 0
    for p in sorted(Path("v2", f"org_{org}").rglob("*.py")):
        q = Path("v1") / p.relative_to("v2")
        a, b = q.read_text().splitlines(), p.read_text().splitlines()
        if a != b:
            files.append(p.name)
            added += len(b) - len(a)
    return files, added


print("\n=== Task 5.2 - change effort (v1 -> v2)")
print(f"{'organisation':<30}{'files changed':>14}{'lines added':>13}  files")
names = {"a": "(a) one script", "b": "(b) one module + main", "c": "(c) three modules", "d": "(d) package"}
for org in "abcd":
    files, added = changed(org)
    total_files = len(list(Path("v1", f"org_{org}").rglob("*.py")))
    print(f"{names[org]:<30}{len(files):>9} of {total_files:<2}{added:>13}  {', '.join(files)}")

print("\n=== size of each file (lines), version 1")
for org in "abcd":
    parts = [f"{p.name}={len(p.read_text().splitlines())}" for p in sorted(Path("v1", f"org_{org}").rglob("*.py"))]
    print(f"{names[org]:<30}" + "  ".join(parts))
