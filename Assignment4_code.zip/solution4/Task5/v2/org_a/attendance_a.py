"""(a) Everything in one script."""
from pathlib import Path


class InvalidRecord(Exception):
    """A line is not 'regno,date,P|A'."""


def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    regno, date, status = (p.strip() for p in parts)
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status {status!r}")
    return regno, date, status


def read_month(folder):
    """Return (records, damaged) for every daily file in the folder."""
    records, damaged = [], []
    for path in sorted(Path(folder).glob("*.txt")):
        with path.open(encoding="utf-8") as f:
            for number, line in enumerate(f, start=1):
                if not line.strip():
                    continue
                try:
                    regno, date, status = parse_line(line)
                except InvalidRecord as err:
                    damaged.append((path.name, number, str(err)))
                    continue
                records.append((date, regno, status))
    return records, damaged


def percentages(records):
    """regno -> (present, recorded, percentage)"""
    counts = {}
    for date, regno, status in records:
        present, total = counts.get(regno, (0, 0))
        counts[regno] = (present + (status == "P"), total + 1)
    return {r: (p, t, 100 * p / t) for r, (p, t) in counts.items()}


def below(stats, threshold=75.0):
    return sorted(r for r, (p, t, pct) in stats.items() if pct < threshold)


def streaks(records, n=3):
    """Students absent on n consecutive recorded days."""
    run, found = {}, set()
    for date, regno, status in sorted(records):
        if status == "A":
            run[regno] = run.get(regno, 0) + 1
            if run[regno] >= n:
                found.add(regno)
        else:
            run[regno] = 0
    return sorted(found)


def write_summary(stats, path):
    with open(path, "w", encoding="utf-8") as out:
        out.write("regno,present,recorded,percentage\n")
        for regno in sorted(stats):
            p, t, pct = stats[regno]
            out.write(f"{regno},{p},{t},{pct:.1f}\n")


def write_damaged(damaged, path):
    with open(path, "w", encoding="utf-8") as out:
        for name, number, message in damaged:
            out.write(f"{name} line {number}: {message}\n")


def write_streaks(students, path):
    with open(path, "w", encoding="utf-8") as out:
        for regno in students:
            out.write(regno + "\n")


def main(folder="att5"):
    out = Path(__file__).resolve().parent
    records, damaged = read_month(folder)
    table = percentages(records)
    write_summary(table, out / "summary.csv")
    write_damaged(damaged, out / "damaged.log")
    print("below 75%:", below(table))
    print("damaged lines:", len(damaged))
    write_streaks(streaks(records), out / "streaks.txt")
    print("absent 3 days in a row:", streaks(records))


if __name__ == "__main__":
    main()
