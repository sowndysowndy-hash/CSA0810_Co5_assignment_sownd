"""(c) writing reports."""
def write_summary(stats, path):
    with open(path, "w", encoding="utf-8") as out:
        out.write("regno,present,recorded,percentage\n")
        for regno in sorted(stats):
            p, t, pct = stats[regno]
            out.write(f"{regno},{p},{t},{pct:.1f}\n")


def write_damaged(damaged, path):
    with open(path, "w", encoding="utf-8") as out:
        for name, number, message in damaged:
            out.write(f"{name} line {number}: {message}\n")


def write_streaks(students, path):
    with open(path, "w", encoding="utf-8") as out:
        for regno in students:
            out.write(regno + "\n")
