from pathlib import Path

from attendance_lib import *  # noqa: F401,F403


def main(folder="att5"):
    out = Path(__file__).resolve().parent
    records, damaged = read_month(folder)
    table = percentages(records)
    write_summary(table, out / "summary.csv")
    write_damaged(damaged, out / "damaged.log")
    print("below 75%:", below(table))
    print("damaged lines:", len(damaged))
    write_streaks(streaks(records), out / "streaks.txt")
    print("absent 3 days in a row:", streaks(records))


if __name__ == "__main__":
    main()
