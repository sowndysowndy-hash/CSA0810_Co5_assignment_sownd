"""statistics."""
def percentages(records):
    """regno -> (present, recorded, percentage)"""
    counts = {}
    for date, regno, status in records:
        present, total = counts.get(regno, (0, 0))
        counts[regno] = (present + (status == "P"), total + 1)
    return {r: (p, t, 100 * p / t) for r, (p, t) in counts.items()}


def below(stats, threshold=75.0):
    return sorted(r for r, (p, t, pct) in stats.items() if pct < threshold)


def streaks(records, n=3):
    """Students absent on n consecutive recorded days."""
    run, found = {}, set()
    for date, regno, status in sorted(records):
        if status == "A":
            run[regno] = run.get(regno, 0) + 1
            if run[regno] >= n:
                found.add(regno)
        else:
            run[regno] = 0
    return sorted(found)
