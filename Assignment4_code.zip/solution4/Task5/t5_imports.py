"""Task 5.3 - the three import styles, a naming conflict, and the one-time import cost (sys.modules cache)."""
import subprocess
import sys
import time
import tracemalloc

sys.path.insert(0, "v1/org_d")

print("1) import attendance.stats            -> you must write the full path")
import attendance.stats                      # noqa: E402
print("   attendance.stats.percentages(...) =", attendance.stats.percentages([("d", "1", "P")]))
print("   names now in this namespace:", [n for n in ("attendance", "stats", "percentages") if n in globals()])

print("\n2) from attendance import stats        -> the sub-module name is enough")
from attendance import stats                 # noqa: E402
print("   stats.percentages(...) =", stats.percentages([("d", "1", "P")]))
print("   names now in this namespace:", [n for n in ("attendance", "stats", "percentages") if n in globals()])

print("\n3) from attendance.stats import percentages  -> the function itself, no prefix")
from attendance.stats import percentages     # noqa: E402
print("   percentages(...) =", percentages([("d", "1", "P")]))
print("   names now in this namespace:", [n for n in ("attendance", "stats", "percentages") if n in globals()])

print("\nNaming conflict: two modules that both define a function called percentages")
import types                                  # noqa: E402
m1, m2 = types.ModuleType("m1"), types.ModuleType("m2")
m1.percentages = lambda: "from m1"
m2.percentages = lambda: "from m2"
from_m1, from_m2 = m1.percentages, m2.percentages
percentages = from_m1                         # style 3 for m1 ...
percentages = from_m2                         # ... then style 3 for m2 silently replaces it
print("   style 3 twice  : percentages() ->", percentages(), "(m1's function is gone)")
print("   style 1 or 2   : m1.percentages() ->", m1.percentages(), "| m2.percentages() ->", m2.percentages())

print("\nImport cost: a package is loaded ONCE and kept in sys.modules")
code = ("import sys, time, tracemalloc\nsys.path.insert(0, 'v1/org_d')\n"
        "tracemalloc.start()\nt0=time.perf_counter()\nimport attendance.reader, attendance.stats, attendance.report\n"
        "first=time.perf_counter()-t0\nmem=tracemalloc.get_traced_memory()[0]\n"
        "t0=time.perf_counter()\nimport attendance.reader, attendance.stats, attendance.report\nagain=time.perf_counter()-t0\n"
        "print(first*1e6, again*1e6, mem/1024, [m for m in sys.modules if m.startswith('attendance')])")
r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
first, again, mem, mods = r.stdout.strip().split(" ", 3)
print(f"   first import of the package : {float(first):8.0f} microseconds, {float(mem):.0f} KB allocated")
print(f"   second import (cached)      : {float(again):8.1f} microseconds")
print("   modules kept in sys.modules :", mods)
