"""Writes the four organisations (a) one script, (b) one module + main, (c) three modules, (d) package -
in two versions: v1 (original requirement) and v2 (plus the 'absent three days in a row' report)."""
import shutil
from pathlib import Path

READER = '''from pathlib import Path


class InvalidRecord(Exception):
    """A line is not 'regno,date,P|A'."""


def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    regno, date, status = (p.strip() for p in parts)
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status {status!r}")
    return regno, date, status


def read_month(folder):
    """Return (records, damaged) for every daily file in the folder."""
    records, damaged = [], []
    for path in sorted(Path(folder).glob("*.txt")):
        with path.open(encoding="utf-8") as f:
            for number, line in enumerate(f, start=1):
                if not line.strip():
                    continue
                try:
                    regno, date, status = parse_line(line)
                except InvalidRecord as err:
                    damaged.append((path.name, number, str(err)))
                    continue
                records.append((date, regno, status))
    return records, damaged
'''

STATS_V1 = '''def percentages(records):
    """regno -> (present, recorded, percentage)"""
    counts = {}
    for date, regno, status in records:
        present, total = counts.get(regno, (0, 0))
        counts[regno] = (present + (status == "P"), total + 1)
    return {r: (p, t, 100 * p / t) for r, (p, t) in counts.items()}


def below(stats, threshold=75.0):
    return sorted(r for r, (p, t, pct) in stats.items() if pct < threshold)
'''

STATS_V2_EXTRA = '''

def streaks(records, n=3):
    """Students absent on n consecutive recorded days."""
    run, found = {}, set()
    for date, regno, status in sorted(records):
        if status == "A":
            run[regno] = run.get(regno, 0) + 1
            if run[regno] >= n:
                found.add(regno)
        else:
            run[regno] = 0
    return sorted(found)
'''

REPORT_V1 = '''def write_summary(stats, path):
    with open(path, "w", encoding="utf-8") as out:
        out.write("regno,present,recorded,percentage\\n")
        for regno in sorted(stats):
            p, t, pct = stats[regno]
            out.write(f"{regno},{p},{t},{pct:.1f}\\n")


def write_damaged(damaged, path):
    with open(path, "w", encoding="utf-8") as out:
        for name, number, message in damaged:
            out.write(f"{name} line {number}: {message}\\n")
'''

REPORT_V2_EXTRA = '''

def write_streaks(students, path):
    with open(path, "w", encoding="utf-8") as out:
        for regno in students:
            out.write(regno + "\\n")
'''


def main_body(v, rd, st, rp):
    """The main() function; rd/st/rp are the prefixes in front of the function names."""
    body = f'''def main(folder="att5"):
    out = Path(__file__).resolve().parent
    records, damaged = {rd}read_month(folder)
    table = {st}percentages(records)
    {rp}write_summary(table, out / "summary.csv")
    {rp}write_damaged(damaged, out / "damaged.log")
    print("below 75%:", {st}below(table))
    print("damaged lines:", len(damaged))
'''
    if v == 2:
        body += f'''    {rp}write_streaks({st}streaks(records), out / "streaks.txt")
    print("absent 3 days in a row:", {st}streaks(records))
'''
    return body


def stats_src(v):
    return STATS_V1 + (STATS_V2_EXTRA if v == 2 else "")


def report_src(v):
    return REPORT_V1 + (REPORT_V2_EXTRA if v == 2 else "")


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


for v in (1, 2):
    root = Path(f"v{v}")
    if root.exists():
        shutil.rmtree(root)
    # (a) one script
    write(root / "org_a" / "attendance_a.py",
          '"""(a) Everything in one script."""\n' + READER + "\n\n" + stats_src(v) + "\n\n" + report_src(v) + "\n\n" + main_body(v, "", "", "") +
          '\n\nif __name__ == "__main__":\n    main()\n')
    # (b) one module imported by a main script
    write(root / "org_b" / "attendance_lib.py",
          '"""(b) The module: reading, statistics and reports together."""\n' + READER + "\n\n" + stats_src(v) + "\n\n" + report_src(v))
    write(root / "org_b" / "main_b.py",
          "from pathlib import Path\n\nfrom attendance_lib import *  # noqa: F401,F403\n\n\n" + main_body(v, "", "", "") + '\n\nif __name__ == "__main__":\n    main()\n')
    # (c) three modules in one folder
    write(root / "org_c" / "reader.py", '"""(c) reading daily files."""\n' + READER)
    write(root / "org_c" / "stats.py", '"""(c) statistics."""\n' + stats_src(v))
    write(root / "org_c" / "report.py", '"""(c) writing reports."""\n' + report_src(v))
    write(root / "org_c" / "main_c.py",
          "from pathlib import Path\n\nimport reader\nimport report\nimport stats\n\n\n" + main_body(v, "reader.", "stats.", "report.") +
          '\n\nif __name__ == "__main__":\n    main()\n')
    # (d) package attendance/ with __init__.py and sub-modules
    write(root / "org_d" / "attendance" / "__init__.py", '"""(d) The attendance package."""\n')
    write(root / "org_d" / "attendance" / "reader.py", '"""reading daily files."""\n' + READER)
    write(root / "org_d" / "attendance" / "stats.py", '"""statistics."""\n' + stats_src(v))
    write(root / "org_d" / "attendance" / "report.py", '"""writing reports."""\n' + report_src(v))
    write(root / "org_d" / "main_d.py",
          "from pathlib import Path\n\nfrom attendance import reader, report, stats\n\n\n" + main_body(v, "reader.", "stats.", "report.") +
          '\n\nif __name__ == "__main__":\n    main()\n')
print("organisations written")
