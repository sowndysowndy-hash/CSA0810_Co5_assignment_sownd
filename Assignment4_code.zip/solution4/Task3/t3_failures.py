"""Task 3.1 - provoke every failure of the attendance processor and record the exception that Python raises."""
import os
import stat
import tempfile
from pathlib import Path

from t2_attendance import process_month  # noqa: E402  (module copied from Task2 into this folder)


def attempt(label, action):
    try:
        action()
        print(f"{label:<22} -> no exception")
    except Exception as err:                           # only here, to REPORT the exception type
        print(f"{label:<22} -> {type(err).__name__}: {err}")


tmp = Path(tempfile.mkdtemp())

# 1 missing folder: glob() on a missing folder simply finds nothing, so we ask for the folder itself
attempt("missing folder", lambda: next(os.scandir(tmp / "no_such_folder")))
# 2 missing file
attempt("missing file", lambda: open(tmp / "2026-10-09.txt", encoding="utf-8"))
# 3 permission denied (a file without read permission)
locked = tmp / "locked.txt"
locked.write_text("192311001,2026-10-01,P\n", encoding="utf-8")
os.chmod(locked, 0)
if os.getuid() == 0:        # root ignores permissions, so repeat the attempt as an ordinary user ("nobody")
    import subprocess
    import sys
    code = f"open({str(locked)!r}, encoding='utf-8').read()"
    r = subprocess.run([sys.executable, "-c", code], user=65534, capture_output=True, text=True)
    last = r.stderr.strip().splitlines()[-1] if r.stderr.strip() else "no exception"
    print(f"{'permission denied':<22} -> {last}")
else:
    attempt("permission denied", lambda: open(locked, encoding="utf-8").read())
os.chmod(locked, stat.S_IRUSR | stat.S_IWUSR)
# 4 wrong encoding
bad = tmp / "latin.txt"
bad.write_bytes("192311001,2026-10-01,P\nM\xfcller,2026-10-01,A\n".encode("latin-1"))
attempt("wrong encoding", lambda: open(bad, encoding="utf-8").read())
# 5 damaged line: too few fields, and a non-number
attempt("damaged (index)", lambda: "192311001,2026-10-01".split(",")[2])
attempt("damaged (value)", lambda: int("P"))
# 6 empty file: nothing is raised, but the result must be handled
empty = tmp / "empty.txt"
empty.write_text("", encoding="utf-8")
print(f"{'empty file':<22} -> no exception, lines read = {len(open(empty, encoding='utf-8').readlines())}")
# a path that is a folder, not a file
attempt("folder given as file", lambda: open(tmp, encoding="utf-8"))
