"""Task 3.2 / 3.3 - custom exception and the complete try statement (try / except / else / finally, raise ... from)."""


class InvalidRecord(Exception):
    """A line of the attendance file is not 'regno,date,P|A'. Raised by parse_line, handled in summarise."""


class FileProblem(Exception):
    """The file itself cannot be used (missing, locked, not UTF-8 text)."""


def parse_line(line):
    parts = line.strip().split(",")
    try:
        regno, date, status = parts                       # ValueError if there are not exactly 3 fields
    except ValueError as err:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}") from err   # keep the original cause
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status {status!r}")
    return regno, date, status


def read_lines(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.readlines()
    except FileNotFoundError as err:
        raise FileProblem(f"{path}: file not found") from err
    except PermissionError as err:
        raise FileProblem(f"{path}: permission denied") from err
    except UnicodeDecodeError as err:
        raise FileProblem(f"{path}: not valid UTF-8 text") from err


def summarise(path):
    present = absent = 0
    errors = []
    try:
        lines = read_lines(path)                          # may raise FileProblem
    except FileProblem as err:
        errors.append((0, str(err)))                      # handled here: report and go on
    else:                                                 # runs only when the file was read successfully
        for number, line in enumerate(lines, start=1):
            if not line.strip():
                continue
            try:
                _, _, status = parse_line(line)
            except InvalidRecord as err:
                errors.append((number, str(err)))
            else:
                if status == "P":
                    present += 1
                else:
                    absent += 1
    finally:                                              # always runs, error or not
        print(f"[finally] finished with {path}")
    return present, absent, errors


if __name__ == "__main__":
    import os
    import tempfile
    with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding="utf-8") as tmp:
        tmp.write("192311001,2026-10-08,P\n192311002,2026-10-08,A\n192311003,2026-10-08\n192311004,2026-10-08,L\n")
    print(summarise(tmp.name))
    os.remove(tmp.name)
    print(summarise("no_such_file.csv"))
    try:
        parse_line("192311003,2026-10-08")
    except InvalidRecord as err:
        print("InvalidRecord:", err, "| original cause:", repr(err.__cause__))
