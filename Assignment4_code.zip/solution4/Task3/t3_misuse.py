"""Task 3.4 - misuse experiment: 'except Exception: pass' hides a typing error in a variable name."""
from t3_processor import InvalidRecord, parse_line

LINES = ["192311001,2026-10-08,P", "192311002,2026-10-08,A", "192311003,2026-10-08", "192311004,2026-10-08,P"]


def summarise_misused(lines):
    present = absent = 0
    for line in lines:
        try:
            _, _, status = parse_line(line)
            if status == "P":
                presnt += 1                      # typing error: 'presnt' instead of 'present'
            else:
                absent += 1
        except Exception:                        # too broad ...
            pass                                 # ... and silent
    return present, absent


def summarise_specific(lines):
    present = absent = 0
    for line in lines:
        try:
            _, _, status = parse_line(line)
        except InvalidRecord:
            continue
        if status == "P":
            presnt += 1                          # the same typing error
        else:
            absent += 1
    return present, absent


print("Broad except + pass :", summarise_misused(LINES), "  <- looks like a valid answer, but the true answer is (2, 1)")
try:
    summarise_specific(LINES)
except Exception as err:
    print("Specific except     :", type(err).__name__ + ":", err)
