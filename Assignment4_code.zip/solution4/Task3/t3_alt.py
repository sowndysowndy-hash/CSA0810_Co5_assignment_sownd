"""Alternative concept: EAFP (raise and catch)  versus  LBYL (check with if before use)."""
import json
import random
import time

N = 200000


class Bad(Exception):
    pass


def eafp(line):
    try:
        regno, date, status = line.split(",")        # ValueError when the field count is wrong
    except ValueError as err:
        raise Bad from err
    if status not in ("P", "A"):
        raise Bad
    return status


def lbyl(line):
    parts = line.split(",")
    if len(parts) != 3:
        return None
    if parts[2] not in ("P", "A"):
        return None
    return parts[2]


def run_eafp(lines):
    good = bad = 0
    for line in lines:
        try:
            eafp(line)
            good += 1
        except Bad:
            bad += 1
    return good, bad


def run_lbyl(lines):
    good = bad = 0
    for line in lines:
        if lbyl(line) is None:
            bad += 1
        else:
            good += 1
    return good, bad


rnd = random.Random(5)
res = []
print(f"{'bad lines':>10}{'EAFP try/except (ns/line)':>28}{'LBYL if (ns/line)':>22}{'EAFP/LBYL':>11}  same result")
for rate in (0.0, 0.01, 0.10, 0.50, 1.0):
    lines = ["192311001,2026-10-08,P" if rnd.random() >= rate else "192311001,2026-10-08" for _ in range(N)]
    t = {}
    for name, fn in (("eafp", run_eafp), ("lbyl", run_lbyl)):
        best = 1e9
        for _ in range(3):
            t0 = time.perf_counter(); r = fn(lines); best = min(best, time.perf_counter() - t0)
        t[name] = (best / N * 1e9, r)
    print(f"{rate:>10.0%}{t['eafp'][0]:>28.0f}{t['lbyl'][0]:>22.0f}{t['eafp'][0] / t['lbyl'][0]:>10.2f}x  {t['eafp'][1] == t['lbyl'][1]}")
    res.append({"bad_rate": rate, "eafp_ns": t["eafp"][0], "lbyl_ns": t["lbyl"][0]})
json.dump(res, open("t3_alt_results.json", "w"), indent=1)
