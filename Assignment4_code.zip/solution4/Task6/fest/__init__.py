"""fest - College Fest Registration Desk package.

reader.py     reads the department files (never stops on a missing or unreadable file)
validator.py  checks one registration line (raises InvalidRegistration)
writer.py     writes the master list, event-wise files, summary report and error log
pipeline.py   connects the three steps
"""
