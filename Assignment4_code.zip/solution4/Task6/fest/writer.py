"""Writing the four outputs."""
from pathlib import Path


def write_all(out_dir, master, summary_lines, errors):
    out = Path(out_dir)
    (out / "events").mkdir(parents=True, exist_ok=True)
    with open(out / "master.csv", "w", encoding="utf-8") as f:
        f.write("regno,name,department,email,events\n")
        for regno in sorted(master):
            _, name, dept, email, events = master[regno]
            f.write(f"{regno},{name},{dept},{email},{';'.join(events)}\n")
    by_event = {}
    for regno in sorted(master):
        for event in master[regno][4]:
            by_event.setdefault(event, []).append(f"{regno} {master[regno][1]}")
    for event, people in by_event.items():
        with open(out / "events" / f"{event}.txt", "w", encoding="utf-8") as f:
            f.write("\n".join(people) + "\n")
    with open(out / "summary.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(summary_lines) + "\n")
    with open(out / "errors.log", "w", encoding="utf-8") as f:
        for message in errors:
            f.write(message + "\n")
    return by_event
