"""Reading the department files."""
from pathlib import Path


def read_department(path):
    """Return (lines, problem): the numbered lines of one file, or a message if the file cannot be used."""
    path = Path(path)
    try:
        with path.open(encoding="utf-8") as f:
            return [(n, line.rstrip("\n")) for n, line in enumerate(f, start=1)], None
    except FileNotFoundError:
        return [], f"{path.name}: department file is missing"
    except PermissionError:
        return [], f"{path.name}: permission denied"
    except UnicodeDecodeError:
        return [], f"{path.name}: not valid UTF-8 text"
