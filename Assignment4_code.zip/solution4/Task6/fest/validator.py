"""Checking one registration line:  regno,name,department,email,event1;event2"""
from .errors import InvalidRegistration

EVENTS = {"Dance", "Music", "Drama", "Quiz", "Art"}


def valid_email(email):
    """E-mail check with string methods only."""
    if " " in email or email.count("@") != 1:
        return False
    local, domain = email.split("@")
    if not local or "." not in domain:
        return False
    if domain.startswith(".") or domain.endswith(".") or ".." in domain:
        return False
    return len(domain.rsplit(".", 1)[1]) >= 2


def parse_registration(line):
    """Return (regno, name, department, email, events) or raise InvalidRegistration."""
    parts = [p.strip() for p in line.split(",")]
    if len(parts) != 5:
        raise InvalidRegistration(f"damaged line: expected 5 fields, found {len(parts)}")
    regno, name, dept, email, events_text = parts
    if not (regno.isdigit() and len(regno) == 9):
        raise InvalidRegistration(f"register number {regno!r} must have 9 digits")
    if not name:
        raise InvalidRegistration("name is empty")
    if not valid_email(email):
        raise InvalidRegistration(f"invalid e-mail {email!r}")
    events = sorted({e.strip().title() for e in events_text.split(";") if e.strip()})
    if not events:
        raise InvalidRegistration("no event chosen")
    unknown = [e for e in events if e not in EVENTS]
    if unknown:
        raise InvalidRegistration(f"unknown event {unknown[0]!r}")
    return regno, name, dept.upper(), email.lower(), events
