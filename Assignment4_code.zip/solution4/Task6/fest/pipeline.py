"""The whole flow: read -> validate -> remove duplicates -> write."""
from collections import Counter

from .errors import InvalidRegistration
from .reader import read_department
from .validator import parse_registration
from .writer import write_all

DEPARTMENTS = ["cse", "ece", "mech", "civil", "it"]


def run(data_dir, out_dir):
    master, errors, seen = {}, [], set()
    counts = {"lines": 0, "accepted": 0, "duplicates": 0, "rejected": 0}
    files_read, files_missing = 0, 0
    for dept in DEPARTMENTS:
        lines, problem = read_department(f"{data_dir}/{dept}.txt")
        if problem:                                        # a missing file never stops the program
            errors.append(problem)
            files_missing += 1
            continue
        files_read += 1
        for number, line in lines:
            if not line.strip():
                continue
            counts["lines"] += 1
            try:
                record = parse_registration(line)
            except InvalidRegistration as err:
                counts["rejected"] += 1
                errors.append(f"{dept}.txt line {number}: {err}")
                continue
            if record[0] in seen:                          # set: O(1) average look-up
                counts["duplicates"] += 1
                errors.append(f"{dept}.txt line {number}: duplicate registration {record[0]} (first one kept)")
                continue
            seen.add(record[0])
            master[record[0]] = record
            counts["accepted"] += 1
    summary = [f"Department files read   : {files_read} of {len(DEPARTMENTS)} ({files_missing} missing)",
               f"Registration lines      : {counts['lines']}",
               f"Accepted (master list)  : {counts['accepted']}",
               f"Duplicates removed      : {counts['duplicates']}",
               f"Rejected lines          : {counts['rejected']}"]
    event_counts = Counter(e for record in master.values() for e in record[4])
    summary += [f"  {event:<6}: {n} participant(s)" for event, n in sorted(event_counts.items())]
    write_all(out_dir, master, summary, errors)
    return master, errors, summary
