class InvalidRegistration(Exception):
    """One registration line breaks a rule (damaged, bad e-mail, unknown event ...)."""
