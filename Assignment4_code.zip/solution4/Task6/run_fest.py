"""Demonstration: run the fest package on clean files and on messy files."""
import sys

from fest.pipeline import run

data_dir, out_dir = sys.argv[1], sys.argv[2]
master, errors, summary = run(data_dir, out_dir)
print(f"=== {data_dir}")
print("\n".join(summary))
print("--- errors.log")
print("\n".join(errors) if errors else "(no errors)")
print("--- master.csv")
print(open(f"{out_dir}/master.csv", encoding="utf-8").read().rstrip("\n"))
