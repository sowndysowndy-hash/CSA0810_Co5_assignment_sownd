"""Alternative concept: detect duplicate registrations with a LIST of earlier register numbers  versus a SET."""
import json
import random
import sys
import time
import tracemalloc


def dedupe_list(regs):
    seen, kept = [], 0
    for r in regs:
        if r in seen:                    # scans the list: O(n) per look-up
            continue
        seen.append(r)
        kept += 1
    return kept


def dedupe_set(regs):
    seen, kept = set(), 0
    for r in regs:
        if r in seen:                    # hash look-up: O(1) on average
            continue
        seen.add(r)
        kept += 1
    return kept


rnd = random.Random(11)
res = []
print(f"{'n':>8}{'list search (s)':>18}{'set (s)':>12}{'ratio':>9}  same   list KB   set KB")
for n in (2000, 5000, 10000, 20000, 40000):
    regs = [str(192300000 + rnd.randrange(n * 4 // 5)) for _ in range(n)]      # about 20% duplicates
    t0 = time.perf_counter(); a = dedupe_list(regs); tl = time.perf_counter() - t0
    best = 1e9
    for _ in range(3):
        t0 = time.perf_counter(); b = dedupe_set(regs); best = min(best, time.perf_counter() - t0)
    seen_l, seen_s = list(dict.fromkeys(regs)), set(regs)
    kl, ks = sys.getsizeof(seen_l) / 1024, sys.getsizeof(seen_s) / 1024
    print(f"{n:>8,}{tl:>18.4f}{best:>12.4f}{tl / best:>8.0f}x  {a == b!s:<6}{kl:>8.0f}{ks:>9.0f}")
    res.append({"n": n, "list_s": tl, "set_s": best, "list_kb": kl, "set_kb": ks, "same": a == b})
json.dump(res, open("t6_alt_results.json", "w"), indent=1)
