"""Alternative concept: manual open/close inside try/finally versus the with statement."""
import builtins
import json
import time

with open("sample.txt", "w", encoding="utf-8") as f:
    f.write("Python Basics\nData Structures\n")

opened = []
real_open = builtins.open


def spy_open(*a, **k):
    f = real_open(*a, **k)
    opened.append(f)
    return f


def with_version(fail):
    with builtins.open("sample.txt", encoding="utf-8") as f:
        data = f.read()
        if fail:
            raise RuntimeError("error while processing")
    return data


def finally_version(fail):
    f = builtins.open("sample.txt", encoding="utf-8")
    try:
        data = f.read()
        if fail:
            raise RuntimeError("error while processing")
        return data
    finally:
        f.close()


def careless_version(fail):                     # no with, no finally: close() is skipped when an error occurs
    f = builtins.open("sample.txt", encoding="utf-8")
    data = f.read()
    if fail:
        raise RuntimeError("error while processing")
    f.close()
    return data


builtins.open = spy_open
print(f"{'version':<22}{'files still open after 1,000 failing calls':>45}")
res = {}
for name, fn in (("with statement", with_version), ("try / finally", finally_version), ("no with, no finally", careless_version)):
    opened.clear()
    for _ in range(1000):
        try:
            fn(True)
        except RuntimeError:
            pass
    still_open = sum(1 for f in opened if not f.closed)
    print(f"{name:<22}{still_open:>45}")
    res[name] = still_open
    for f in opened:
        f.close()
builtins.open = real_open

print(f"\n{'version':<22}{'time for 20,000 open+read (s)':>32}")
for name, fn in (("with statement", with_version), ("try / finally", finally_version)):
    best = 1e9
    for _ in range(3):
        t0 = time.perf_counter()
        for _ in range(20000):
            fn(False)
        best = min(best, time.perf_counter() - t0)
    print(f"{name:<22}{best:>32.3f}")
    res[name + " time_s"] = best
json.dump(res, open("t4_alt_results.json", "w"), indent=1)
