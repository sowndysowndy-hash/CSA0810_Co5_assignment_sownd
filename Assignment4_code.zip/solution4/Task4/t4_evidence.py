"""Task 4.2 - evidence: run the ORIGINAL process() for three days and show each defect."""
import builtins
import os

from t4_original import process, save_returns

DAYS = {
    "day1.txt": ["Python Basics", "Data Structures"],
    "day2.txt": ["Operating Systems", "Networks", "Compilers"],
    "day3.txt": ["Databases"],
}
for name, books in DAYS.items():
    with open(name, "w", encoding="utf-8") as f:
        f.write("\n".join(books) + "\n")
if os.path.exists("returns.log"):
    os.remove("returns.log")

# keep a list of every file object that open() creates, so that we can check whether it was closed
opened = []
real_open = builtins.open


def spy_open(*args, **kwargs):
    f = real_open(*args, **kwargs)
    opened.append(f)
    return f


builtins.open = spy_open

print("Defect 1 - earlier days are lost (mode 'w' truncates the log every time)")
for name in DAYS:
    process(name)
    print(f"  after {name}: log = {real_open('returns.log').read()!r}")

print("\nDefect 2 - books are joined together (write() does not add a newline)")
process("day2.txt")
print("  day2 written ->", repr(real_open("returns.log").read()), "(no separator between the book titles)")

print("\nDefect 3 - an error inside write() leaves the log open and unsaved")
opened.clear()
try:
    save_returns(["Databases", None])          # None is not a string: write() raises TypeError
except TypeError as err:
    print("  TypeError:", err)
log_handle = [f for f in opened if f.name == "returns.log"][0]
print("  log file closed?", log_handle.closed, " (close() was never reached)")

print("\nDefect 4 - the day file itself is never closed, and other errors escape silently")
opened.clear()
process("day1.txt")
print("  day file closed?", [f.closed for f in opened if f.name == "day1.txt"])
real_open("day_latin.txt", "wb").write("Caf\xe9 Society\n".encode("latin-1"))
try:
    process("day_latin.txt")
except UnicodeDecodeError as err:
    print("  UnicodeDecodeError escapes (only FileNotFoundError is caught) - nothing is written to any log")
builtins.open = real_open
