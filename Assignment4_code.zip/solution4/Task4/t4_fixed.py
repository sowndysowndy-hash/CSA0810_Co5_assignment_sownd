"""Task 4.3 - repaired library program: append mode, newlines, with statements and an error log."""
from datetime import datetime


def log_error(message, log_name="errors.log"):
    with open(log_name, "a", encoding="utf-8") as err_log:
        err_log.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {message}\n")


def save_returns(books, log_name="returns.log"):
    with open(log_name, "a", encoding="utf-8") as log:        # "a" keeps earlier days; with always closes
        for b in books:
            log.write(b + "\n")                               # one book per line


def process(day_file):
    try:
        with open(day_file, encoding="utf-8") as f:
            books = [line.strip() for line in f if line.strip()]
        save_returns(books)
    except FileNotFoundError:
        log_error(f"{day_file}: file not found")
    except PermissionError:
        log_error(f"{day_file}: permission denied")
    except UnicodeDecodeError as err:
        log_error(f"{day_file}: not valid UTF-8 text ({err.reason})")
    except OSError as err:
        log_error(f"{day_file}: {type(err).__name__} {err}")


if __name__ == "__main__":
    import os
    for stale in ("returns.log", "errors.log"):
        if os.path.exists(stale):
            os.remove(stale)
    for name in ("day1.txt", "day2.txt", "day3.txt", "day4_missing.txt", "day_latin.txt"):
        process(name)
    print("--- returns.log")
    print(open("returns.log", encoding="utf-8").read().rstrip("\n"))
    print("--- errors.log")
    print(open("errors.log", encoding="utf-8").read().rstrip("\n"))
