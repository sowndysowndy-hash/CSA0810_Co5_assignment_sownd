# CSA08 – Assignment 3 (CO3): Python Data Structures

- **Name:** P Sowndarya
- **Register number:** 1912260537
- **Course:** CSA0821 – Python Programming

This repository is organized into one folder per task. The `output/` folder inside each task contains page images from the submitted Assignment 3 report showing the implementation, output, and analysis for that task.

## Tasks
1. Lists and Slicing – Daily Rainfall Records
2. Tuples, Mutability and Copying
3. Dictionaries – Farmer Helpline Complaint Analysis
4. Sets – Elective Registration Clash
5. List Comprehension – Cleaning
6. Nested Data – Railway Timetable
7. Design a Contact-Merging Program

## How to use
Open each `Task_XX` folder and review its `output/` page images. The Python source code is shown in the assignment report screenshots. For clean runnable `.py` files, code should be transcribed/checked from those screenshots before committing; OCR/transcription is not included as executable source in this package.

## Commit plan (separate commit per task)
```bash
git init
git add README.md && git commit -m "Add Assignment 3 README"
git add Task_01 && git commit -m "Task 1: add report pages"
git add Task_02 && git commit -m "Task 2: add report pages"
git add Task_03 && git commit -m "Task 3: add report pages"
git add Task_04 && git commit -m "Task 4: add report pages"
git add Task_05 && git commit -m "Task 5: add report pages"
git add Task_06 && git commit -m "Task 6: add report pages"
git add Task_07 && git commit -m "Task 7: add report pages"
git branch -M main
git remote add origin https://github.com/<your-username>/CSA08-1912260537-Assignment3.git
git push -u origin main
```
