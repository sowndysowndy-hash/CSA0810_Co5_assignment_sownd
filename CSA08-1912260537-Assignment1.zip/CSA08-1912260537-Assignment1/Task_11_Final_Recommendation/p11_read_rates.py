# Reading milk rates from a JSON file
import json
from decimal import Decimal

with open("rates.json", "r") as file:
    data = json.load(file)

base_rate = Decimal(data["base_rate"])
fat_value = Decimal(data["fat_step_value"])
snf_value = Decimal(data["snf_step_value"])

print("Base Rate:", base_rate)
print("Fat Step:", fat_value)
print("SNF Step:", snf_value)
