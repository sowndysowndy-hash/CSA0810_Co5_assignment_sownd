from decimal import Decimal, ROUND_HALF_UP
BASE_RATE = Decimal("30.00")
FAT_STEP = Decimal("0.40")
SNF_STEP = Decimal("0.30")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
STEP_SIZE = Decimal("0.1")

def calculate_rate(fat, snf):
    fat = Decimal(str(fat))
    snf = Decimal(str(snf))
    if not fat.is_finite() or not snf.is_finite():
        raise ValueError("Invalid milk quality reading")
    if fat < Decimal("2.0") or fat > Decimal("7.0"):
        raise ValueError("Fat must be between 2.0 and 7.0")
    if snf < 0:
        raise ValueError("SNF cannot be negative")
    fat_steps = (
        (fat - STANDARD_FAT) / STEP_SIZE
    ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    snf_steps = (
        (snf - STANDARD_SNF) / STEP_SIZE
    ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    rate = BASE_RATE + fat_steps * FAT_STEP + snf_steps * SNF_STEP
    return rate.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

def calculate_payment(litres, fat, snf):
    litres = Decimal(str(litres))
    if litres < 0:
        raise ValueError("Litres cannot be negative")
    rate = calculate_rate(fat, snf)
    return (litres * rate).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )

print("Milk Rate:", calculate_rate(4.2, 8.7))
print("Payment:", calculate_payment(10, 4.2, 8.7))
