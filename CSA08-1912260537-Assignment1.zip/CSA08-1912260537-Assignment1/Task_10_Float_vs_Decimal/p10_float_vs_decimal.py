import time
from decimal import Decimal, ROUND_HALF_EVEN

def float_payment(litres, fat, snf):
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)
    rate = round(
        30 + fat_steps * 0.40
        + snf_steps * 0.30,
        2
    )
    return round(litres * rate, 2)

def decimal_payment(litres, fat, snf):
    litres = Decimal(str(litres))
    fat = Decimal(str(fat))
    snf = Decimal(str(snf))
    fat_steps = int(
        ((fat - Decimal("3.5")) / Decimal("0.1"))
        .to_integral_value(rounding=ROUND_HALF_EVEN)
    )
    snf_steps = int(
        ((snf - Decimal("8.5")) / Decimal("0.1"))
        .to_integral_value(rounding=ROUND_HALF_EVEN)
    )
    rate = (
        Decimal("30.00")
        + fat_steps * Decimal("0.40")
        + snf_steps * Decimal("0.30")
    ).quantize(Decimal("0.01"))
    return (litres * rate).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_EVEN
    )

for n in (300, 6000, 150000):
    start = time.perf_counter()
    f_total = sum(float_payment(8.5, 4.2, 8.7) for _ in range(n))
    f_time = time.perf_counter() - start

    start = time.perf_counter()
    d_total = sum(
        (decimal_payment(8.5, 4.2, 8.7) for _ in range(n)),
        Decimal("0.00")
    )
    d_time = time.perf_counter() - start

    print("Payments:", n)
    print(f"Float Total: Rs {f_total:.2f}")
    print(f"Decimal Total: Rs {d_total:.2f}")
    print(f"Float Time: {f_time:.6f} seconds")
    print(f"Decimal Time: {d_time:.6f} seconds")
    print()
