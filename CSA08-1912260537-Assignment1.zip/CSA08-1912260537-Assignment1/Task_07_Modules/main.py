from milkrate import rate_per_litre, payout

rate = rate_per_litre(4.2, 8.7)
payment = payout(10, 4.2, 8.7)
print(f"Milk Rate: Rs {rate:.2f}")
print(f"Payment: Rs {payment:.2f}")
