"""Milk rate calculation module."""
BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5

def rate_per_litre(fat, snf):
    """Calculate milk rate per litre."""
    fat_steps = round((fat - STANDARD_FAT) / 0.1)
    snf_steps = round((snf - STANDARD_SNF) / 0.1)
    rate = (
        BASE_RATE
        + fat_steps * FAT_STEP_VALUE
        + snf_steps * SNF_STEP_VALUE
    )
    return round(rate, 2)

def payout(litres, fat, snf):
    """Calculate payment for one milk entry."""
    rate = rate_per_litre(fat, snf)
    return round(litres * rate, 2)

if __name__ == "__main__":
    for litres, fat, snf in [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]:
        print(f"Litres: {litres}, Rate: {rate_per_litre(fat, snf):.2f}, "
              f"Payment: {payout(litres, fat, snf):.2f}")
