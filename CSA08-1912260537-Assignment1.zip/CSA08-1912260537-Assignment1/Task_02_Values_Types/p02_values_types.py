from decimal import Decimal
farmer_id = 101
litres = 12.5
shift = "Morning"
active = True
print(type(farmer_id))
print(type(litres))
print(type(shift))
print(type(active))
print(7 / 2)
print(7 // 2)
print(7 % 2)
print(0.1 + 0.2 == 0.3)
print(Decimal("0.1") + Decimal("0.2"))
print(Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))
