def read_number(message):
    while True:
        try:
            value = float(input(message).strip())
            if value < 0:
                print("Enter a non-negative value.")
                continue
            return value
        except ValueError:
            print("Invalid input! Please enter a number.")

litres = read_number("Enter milk quantity: ")
fat = read_number("Enter fat percentage: ")
snf = read_number("Enter SNF percentage: ")
BASE_RATE = 30.00
FAT_STEP = 0.40
SNF_STEP = 0.30
fat_steps = round((fat - 3.5) / 0.1)
snf_steps = round((snf - 8.5) / 0.1)
rate = round(
    BASE_RATE + fat_steps * FAT_STEP
    + snf_steps * SNF_STEP, 2
)
amount = round(litres * rate, 2)
print()
print("MILK PAYMENT DETAILS")
print("-" * 25)
print(f"Litres : {litres:.2f}")
print(f"Fat    : {fat:.2f}")
print(f"SNF    : {snf:.2f}")
print(f"Rate   : Rs {rate:.2f}")
print(f"Amount : Rs {amount:.2f}")
