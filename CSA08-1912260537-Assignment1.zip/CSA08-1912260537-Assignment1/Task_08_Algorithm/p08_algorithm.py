def calculate_payment(litres, fat, snf):
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)
    rate = round(
        30 + fat_steps * 0.40
        + snf_steps * 0.30,
        2
    )
    payment = round(litres * rate, 2)
    return payment

entries = [
    (10, 3.5, 8.5),
    (8.5, 4.2, 8.7),
    (12, 3.1, 8.3)
]
total = 0
for litres, fat, snf in entries:
    payment = calculate_payment(litres, fat, snf)
    total += payment
    print(f"Payment: Rs {payment:.2f}")
print(f"Ten-Day Total: Rs {total:.2f}")
