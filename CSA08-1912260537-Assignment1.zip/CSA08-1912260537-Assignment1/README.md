# CSA0821 – Assessment 1: Village Milk Co-operative Payment Calculator

- **Name:** P Sowndarya
- **Register number:** 1912260537
- **Slot:** A
- **Course:** CSA0821 – Python Programming
- **Faculty:** Keerthana S
- **Python version:** 3.13 (any Python 3.8+ works)
- **Libraries:** standard library only (`decimal`, `json`, `math`, `time`) – see `requirements.txt`

Each task folder has the source file(s) and an `output/` folder with the captured output
(`.txt` and screenshot `.png`). Timings in Task 10 depend on the machine.

## How to run
```
python Task_02_Values_Types/p02_values_types.py
python Task_03_Variables_Constants/p03_variables_constants.py
python Task_04_Expressions/p04_expressions.py
python Task_05_Input_Output/p05_input_output.py        # type: 10, 4.2, 8.7
python Task_06_Functions/p06_functions.py
cd Task_07_Modules && python main.py && python milkrate.py && cd ..
python Task_08_Algorithm/p08_algorithm.py
python Task_09_Testing/p09_testing.py
python Task_10_Float_vs_Decimal/p10_float_vs_decimal.py
cd Task_11_Final_Recommendation && python p11_final.py && python p11_read_rates.py && cd ..
cd Task_12_Revised_Design && python p12_revised.py && python p12_tests.py && cd ..
```

## Results
| Task | Result |
|---|---|
| 1 | Problem analysis: inputs, outputs, constants, validation rules (`problem_analysis.md`). |
| 2 | int / float / str / bool types; `/`, `//`, `%`; `0.1 + 0.2 == 0.3` is False with float, True with Decimal. |
| 3 | Constants and variables: 10 L, fat 4.0, SNF 9.0 gives rate 33.5 and payment 335.0. |
| 4 | Expressions: fat adjustment 2.0, SNF adjustment 1.5, rate 33.5, payment 335.0. |
| 5 | Input with `float()` conversion and try/except validation: 10 L, 4.2 fat, 8.7 SNF gives Rs 33.40 and Rs 334.00. |
| 6 | Functions `rate_per_litre`, `payout`, `ten_day_total`: ten-day total Rs 917.50. |
| 7 | Module `milkrate.py` imported by `main.py`; `__name__ == "__main__"` guard. |
| 8 | Pseudocode, flowchart, hand trace and program: total Rs 917.50. |
| 9 | Assert-based tests (normal, boundary, invalid inputs) – all pass. |
| 10 | Float vs Decimal for 300 / 6,000 / 150,000 payments: same totals, Decimal about 5x slower. |
| 11 | Final recommendation: Decimal, functions, validation, rates in `rates.json`. |
| 12 | Revised design: summer rate card (Rs 32.00 / 0.45), two-decimal readings, bonus Rs 0.50/L above 500 L. Normal Rs 17,415.00, summer Rs 18,595.00. |

## Commit plan (one commit per task folder)
```
git init
git add README.md requirements.txt && git commit -m "Add README and requirements"
git add Task_01_Problem_Analysis && git commit -m "Task 1: problem analysis"
git add Task_02_Values_Types && git commit -m "Task 2: values and types"
git add Task_03_Variables_Constants && git commit -m "Task 3: variables and constants"
git add Task_04_Expressions && git commit -m "Task 4: expressions"
git add Task_05_Input_Output && git commit -m "Task 5: input and output"
git add Task_06_Functions && git commit -m "Task 6: functions"
git add Task_07_Modules && git commit -m "Task 7: modules"
git add Task_08_Algorithm && git commit -m "Task 8: algorithmic problem solving"
git add Task_09_Testing && git commit -m "Task 9: implementation and testing"
git add Task_10_Float_vs_Decimal && git commit -m "Task 10: float vs Decimal"
git add Task_11_Final_Recommendation && git commit -m "Task 11: final recommendation"
git add Task_12_Revised_Design && git commit -m "Task 12: re-evaluate and adapt the design"
git branch -M main
git remote add origin https://github.com/<your-username>/CSA08-1912260537-Assignment1.git
git push -u origin main
```
Tip: make the commits on different days or at least separately, since the commit history is checked.
