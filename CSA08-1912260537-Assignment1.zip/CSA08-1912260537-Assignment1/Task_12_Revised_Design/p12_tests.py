from decimal import Decimal, ROUND_HALF_UP

def rate_per_litre(fat, snf, season="normal"):
    if season == "summer":
        base = Decimal("32.00")
        fat_value = Decimal("0.45")
    else:
        base = Decimal("30.00")
        fat_value = Decimal("0.40")
    snf_value = Decimal("0.30")
    fat_steps = (
        (Decimal(str(fat)) - Decimal("3.5")) / Decimal("0.1")
    ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    snf_steps = (
        (Decimal(str(snf)) - Decimal("8.5")) / Decimal("0.1")
    ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    rate = base + fat_steps * fat_value + snf_steps * snf_value
    return rate.quantize(Decimal("0.01"))

def bonus(litres):
    litres = Decimal(str(litres))
    if litres > 500:
        return (litres * Decimal("0.50")).quantize(Decimal("0.01"))
    return Decimal("0.00")

def ten_day_total(entries, season="normal"):
    total = Decimal("0.00")
    total_litres = Decimal("0.00")
    for litres, fat, snf in entries:
        litres = Decimal(str(litres))
        rate = rate_per_litre(fat, snf, season)
        total += litres * rate
        total_litres += litres
    total += bonus(total_litres)
    return total.quantize(Decimal("0.01"))

entries = [
    (200, 3.50, 8.50),
    (200, 4.25, 8.50),
    (150, 3.50, 8.50)
]

def test_revised_design():
    assert bonus(400) == Decimal("0.00")
    assert bonus(500) == Decimal("0.00")
    assert bonus(550) == Decimal("275.00")
    assert bonus(600) == Decimal("300.00")
    assert ten_day_total(entries, "normal") == Decimal("17415.00")
    assert ten_day_total(entries, "summer") == Decimal("18595.00")
    print("All revised design tests passed!")

test_revised_design()
for s in ("normal", "summer"):
    print("Season:", s)
    print("Total Payment: Rs", ten_day_total(entries, s))
