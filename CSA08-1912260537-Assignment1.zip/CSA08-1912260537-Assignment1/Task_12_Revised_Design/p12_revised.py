from decimal import Decimal, ROUND_HALF_UP
BASE_RATE = Decimal("32.00")
FAT_STEP = Decimal("0.45")
SNF_STEP = Decimal("0.30")
STANDARD_FAT = Decimal("3.50")
STANDARD_SNF = Decimal("8.50")

def rate_per_litre(fat, snf):
    fat = Decimal(str(fat))
    snf = Decimal(str(snf))
    fat_steps = ((fat - STANDARD_FAT) / Decimal("0.10"))
    snf_steps = ((snf - STANDARD_SNF) / Decimal("0.10"))
    fat_steps = fat_steps.quantize(
        Decimal("1"), rounding=ROUND_HALF_UP)
    snf_steps = snf_steps.quantize(
        Decimal("1"), rounding=ROUND_HALF_UP)
    rate = BASE_RATE + fat_steps * FAT_STEP + snf_steps * SNF_STEP
    return rate.quantize(Decimal("0.01"))

def payout(litres, fat, snf):
    litres = Decimal(str(litres))
    return (litres * rate_per_litre(fat, snf)).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP)

def ten_day_total(entries):
    total_litres = sum(Decimal(str(e[0])) for e in entries)
    total_payment = sum(
        (payout(*e) for e in entries), Decimal("0.00")
    )
    bonus = (total_litres * Decimal("0.50")
             if total_litres > 500 else Decimal("0.00"))
    return total_litres, total_payment, bonus

summer_entries = [
    ("200", "3.50", "8.50"),
    ("200", "4.25", "8.50"),
    ("150", "3.50", "8.50")
]
litres, payment, bonus = ten_day_total(summer_entries)
print("Season: Summer")
print("Total Litres:", litres)
print("Payment Before Bonus: Rs", payment)
print("Bonus: Rs", bonus)
print("Final Payment: Rs", payment + bonus)
