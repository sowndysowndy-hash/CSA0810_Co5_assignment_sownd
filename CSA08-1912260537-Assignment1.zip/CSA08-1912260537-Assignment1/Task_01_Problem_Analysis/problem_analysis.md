# Task 1 – Problem Analysis

## Problem statement
Build a Python program that works out the amount payable to farmers who deliver milk to a village
milk co-operative. The amount depends on the litres supplied, the fat percentage and the SNF
percentage. The program finds the rate per litre, the payment for every entry and the total payment
for ten days.

## Inputs
| Input | Type | Purpose |
|---|---|---|
| Farmer ID | String / Integer | Identifies the farmer |
| Litres | Float | Quantity of milk supplied |
| Fat percentage | Float | Fat content of the milk |
| SNF percentage | Float | Solids-not-fat content |
| Shift | String | Morning or evening collection |

## Outputs
| Output | Type | Purpose |
|---|---|---|
| Rate per litre | Decimal | Price paid for one litre |
| Payment amount | Decimal | Litres x rate per litre |
| Ten-day total | Decimal | Sum of all payments in ten days |

## Constants
BASE_RATE = 30.00, FAT_STEP_VALUE = 0.40, SNF_STEP_VALUE = 0.30, STANDARD_FAT = 3.5, STANDARD_SNF = 8.5

## Validation rules
- Milk quantity must not be negative.
- Fat percentage must lie between 2.0 and 7.0 (both inclusive).
- SNF must be a valid number within the range set by the co-operative.
- Farmer ID must not be empty.
- Shift must be a valid collection shift.
- Payment must follow the approved rate card and rounding rule.

## Alternative design
Separate variables for 300 farmers are hard to maintain. A list of tuples
(farmer_id, litres, fat, snf, shift) lets one loop process every record.
Time complexity O(n); space complexity O(n).

## Conclusion
A dependable milk payment system should use suitable data types, named constants, input validation
and a list-based structure.
