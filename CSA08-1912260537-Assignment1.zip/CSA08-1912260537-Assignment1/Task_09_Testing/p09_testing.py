import math
BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5

def validate(litres, fat, snf):
    values = (litres, fat, snf)
    if not all(
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
        for value in values
    ):
        raise ValueError("Invalid numeric input")

    if litres < 0:
        raise ValueError("Litres cannot be negative")
    if fat < 2.0 or fat > 7.0:
        raise ValueError("Fat must be between 2.0 and 7.0")
    if snf < 0:
        raise ValueError("SNF cannot be negative")

def calculate_payment(litres, fat, snf):
    validate(litres, fat, snf)
    fat_steps = round((fat - STANDARD_FAT) / 0.1)
    snf_steps = round((snf - STANDARD_SNF) / 0.1)
    rate = round(
        BASE_RATE
        + fat_steps * FAT_STEP_VALUE
        + snf_steps * SNF_STEP_VALUE, 2
    )
    return round(litres * rate, 2)

def expect_error(litres, fat, snf):
    try:
        calculate_payment(litres, fat, snf)
    except ValueError:
        return True
    return False

assert calculate_payment(10, 3.5, 8.5) == 300.00
assert calculate_payment(8.5, 4.2, 8.7) == 283.90
assert calculate_payment(12, 3.1, 8.3) == 333.60
assert calculate_payment(10, 2.0, 8.5) == 240.00
assert calculate_payment(10, 7.0, 8.5) == 440.00
assert expect_error("ten", 3.5, 8.5)
assert expect_error(-5, 3.5, 8.5)
assert expect_error(10, 7.5, 8.5)
print("All tests passed successfully!")
