litres = 10.0
fat = 4.0
snf = 9.0
base_rate = 30.00
fat_step_value = 0.40
snf_step_value = 0.30
standard_fat = 3.5
standard_snf = 8.5
fat_steps = round((fat - standard_fat) / 0.1)
snf_steps = round((snf - standard_snf) / 0.1)
fat_adjustment = fat_steps * fat_step_value
snf_adjustment = snf_steps * snf_step_value
rate = base_rate + fat_adjustment + snf_adjustment
payment = litres * rate
print("Fat Adjustment:", round(fat_adjustment, 2))
print("SNF Adjustment:", round(snf_adjustment, 2))
print("Milk Rate:", round(rate, 2))
print("Total Payment:", round(payment, 2))
