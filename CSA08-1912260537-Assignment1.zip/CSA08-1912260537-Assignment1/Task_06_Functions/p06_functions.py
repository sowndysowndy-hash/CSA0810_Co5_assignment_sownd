BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5

def rate_per_litre(fat, snf):
    """Calculate the milk rate per litre."""
    fat_steps = round((fat - STANDARD_FAT) / 0.1)
    snf_steps = round((snf - STANDARD_SNF) / 0.1)
    rate = (
        BASE_RATE
        + fat_steps * FAT_STEP_VALUE
        + snf_steps * SNF_STEP_VALUE
    )
    return round(rate, 2)

def payout(litres, fat, snf):
    """Calculate payment for one milk entry."""
    rate = rate_per_litre(fat, snf)
    payment = litres * rate
    return round(payment, 2)

def ten_day_total(entries):
    """Calculate the total payment for all entries."""
    total = 0
    for litres, fat, snf in entries:
        total += payout(litres, fat, snf)
    return round(total, 2)

entries = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]
for litres, fat, snf in entries:
    print("Litres:", litres)
    print(f"Rate: Rs {rate_per_litre(fat, snf):.2f}")
    print(f"Payment: Rs {payout(litres, fat, snf):.2f}")
    print()
print(f"Total Payment: Rs {ten_day_total(entries):.2f}")
