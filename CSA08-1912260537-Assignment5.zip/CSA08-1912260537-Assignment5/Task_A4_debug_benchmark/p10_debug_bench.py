import io, logging, time

N = 100_000
sink = io.StringIO()

t = time.perf_counter()
for i in range(N):
    print("checking row", i, file=sink)
t_print = time.perf_counter() - t

log = logging.getLogger("clean"); log.propagate = False
h = logging.StreamHandler(io.StringIO()); h.setFormatter(logging.Formatter("%(levelname)s %(message)s")); log.addHandler(h)
log.setLevel(logging.DEBUG)
t = time.perf_counter()
for i in range(N):
    log.debug("checking row %d", i)
t_log_on = time.perf_counter() - t

log.setLevel(logging.WARNING)                       # switched off with ONE line
t = time.perf_counter()
for i in range(N):
    log.debug("checking row %d", i)
t_log_off = time.perf_counter() - t

DEBUG = False
t = time.perf_counter()
for i in range(N):
    if DEBUG:
        print("checking row", i)
t_flag = time.perf_counter() - t

print(f"{N:,} debug messages")
print(f"print() to a buffer           : {t_print:.4f} s  ({t_print / N * 1e6:.2f} us each)")
print(f"logging.debug, level DEBUG    : {t_log_on:.4f} s  ({t_log_on / N * 1e6:.2f} us each)")
print(f"logging.debug, level WARNING  : {t_log_off:.4f} s  ({t_log_off / N * 1e6:.2f} us each)  <- switched off")
print(f"if DEBUG: print(...) (False)  : {t_flag:.4f} s  ({t_flag / N * 1e6:.2f} us each)")
