import csv, io, random, sqlite3, statistics
from datetime import datetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

FAHRENHEIT_STATIONS = {"Velachery", "Manali"}
FIELDS = ["pm25", "pm10", "no2", "temp"]
LIMITS = {"pm25": (0, 999), "pm10": (0, 1999), "no2": (0, 999), "temp": (-30, 60)}
MAX_GAP = 3   # forward-fill at most 3 consecutive missing hours

def std_date(s):
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return None

def to_number(s):
    s = (s or "").strip()
    if s == "" or s.upper() == "NA":
        return None
    try:
        return float(s)
    except ValueError:
        return None

def clean(text):
    st = dict(read=0, bad_date=0, duplicates=0, missing=0, impossible=0,
              fahrenheit=0, filled=0, left_null=0)
    seen, rows = set(), []
    for r in csv.DictReader(io.StringIO(text)):
        st["read"] += 1
        station = " ".join(r["station"].split()).title()
        day = std_date(r["date"])
        if day is None:
            st["bad_date"] += 1
            continue
        key = (station, day, int(r["hour"]))
        if key in seen:
            st["duplicates"] += 1
            continue
        seen.add(key)
        rec = {"station": station, "day": day, "hour": int(r["hour"])}
        for f in FIELDS:
            v = to_number(r[f])
            if v is None:
                st["missing"] += 1
            else:
                if f == "temp" and station in FAHRENHEIT_STATIONS:
                    v = round((v - 32) * 5 / 9, 1)
                    st["fahrenheit"] += 1
                lo, hi = LIMITS[f]
                if not lo <= v <= hi:
                    v = None
                    st["impossible"] += 1
            rec[f] = v
        rows.append(rec)
    rows.sort(key=lambda r: (r["station"], r["day"], r["hour"]))
    by_station = {}
    for r in rows:
        by_station.setdefault(r["station"], []).append(r)
    for recs in by_station.values():
        for f in FIELDS:
            valid = [r[f] for r in recs if r[f] is not None]
            med = statistics.median(valid) if valid else None
            last, gap = None, 0
            for r in recs:
                if r[f] is not None:
                    last, gap = r[f], 0
                    continue
                gap += 1
                if last is None and med is not None:
                    r[f] = med; st["filled"] += 1
                elif last is not None and gap <= MAX_GAP:
                    r[f] = last; st["filled"] += 1
                else:
                    st["left_null"] += 1
    return rows, st

# ---------------- B1.1  small file with every problem ----------------
SMALL = """station,date,hour,pm25,pm10,no2,temp
Adyar,2026-10-01,8,48,90,32,30.5
adyar ,2026-10-01,9,NA,95,35,31.0
ADYAR,2026-10-01,10,,98,36,31.5
Adyar,2026-10-01,8,48,90,32,30.5
Adyar,01/10/2026,11,-5,100,40,32.0
Adyar,2026-10-01,12,5000,102,41,32.5
Guindy,2026-10-01,8,95,150,60,29.0
Guindy,2026-10-01,9,abc,155,61,29.5
Guindy,2026-10-01,10,121,160,63,30.0
Velachery,2026-10-01,8,70,110,45,86.0
Velachery,2026-10-01,9,72,112,46,87.8
Velachery,2026-10-01,10,75,115,47,999
Manali,2026-13-45,8,80,120,50,90.0
"""
print("=== BEFORE CLEANING (13 raw rows) ===")
print(SMALL.strip())
rows, stats = clean(SMALL)
print("\n=== AFTER CLEANING ===")
print(f"{'station':10}{'day':12}{'hr':>3}{'pm25':>8}{'pm10':>8}{'no2':>7}{'temp_c':>8}")
for r in rows:
    f = lambda v: "NULL" if v is None else f"{v:g}"
    print(f"{r['station']:10}{r['day']:12}{r['hour']:>3}{f(r['pm25']):>8}"
          f"{f(r['pm10']):>8}{f(r['no2']):>7}{f(r['temp']):>8}")
print("\nCleaning report:", stats)

# ---------------- one month of data for four stations ----------------
random.seed(7)
BASE = {"Adyar": 55, "Guindy": 85, "Velachery": 65, "Manali": 110}
def hour_effect(h):
    return 28 if h in (7, 8, 9, 18, 19, 20) else -14 if 12 <= h <= 16 else 0
lines = ["station,date,hour,pm25,pm10,no2,temp"]
for name, base in BASE.items():
    for d in range(1, 32):
        for h in range(24):
            temp_c = 27 + 6 * __import__("math").sin((h - 9) / 24 * 2 * 3.14159) + random.gauss(0, 0.8)
            pm25 = base + 0.6 * d + hour_effect(h) - 1.2 * (temp_c - 27) + random.gauss(0, 9)
            temp = temp_c * 9 / 5 + 32 if name in FAHRENHEIT_STATIONS else temp_c
            vals = [round(pm25, 1), round(pm25 * 1.7, 1), round(30 + pm25 * 0.4, 1), round(temp, 1)]
            vals = [str(v) for v in vals]
            x = random.random()
            if x < 0.03: vals[0] = "NA"
            elif x < 0.04: vals[0] = ""
            elif x < 0.05: vals[0] = "-9"
            elif x < 0.055: vals[0] = "5000"
            line = f"{name},2026-10-{d:02d},{h}," + ",".join(vals)
            lines.append(line)
            if random.random() < 0.01:
                lines.append(line)            # duplicate row
month_text = "\n".join(lines) + "\n"
rows, stats = clean(month_text)
print("\n=== OCTOBER FILE (4 stations x 31 days x 24 h) ===")
print("Cleaning report:", stats)

# ---------------- B1.3  store in SQLite with executemany ----------------
con = sqlite3.connect(":memory:")
con.executescript("""
CREATE TABLE stations (station_id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL,
                       original_temp_unit TEXT NOT NULL CHECK (original_temp_unit IN ('C','F')));
CREATE TABLE readings (station_id INTEGER NOT NULL REFERENCES stations(station_id),
                       day TEXT NOT NULL, hour INTEGER NOT NULL,
                       pm25 REAL, pm10 REAL, no2 REAL, temp_c REAL,
                       PRIMARY KEY (station_id, day, hour));
""")
names = sorted({r["station"] for r in rows})
con.executemany("INSERT INTO stations (name, original_temp_unit) VALUES (?, ?)",
                [(n, "F" if n in FAHRENHEIT_STATIONS else "C") for n in names])
ids = dict(con.execute("SELECT name, station_id FROM stations"))
con.executemany("INSERT INTO readings VALUES (?,?,?,?,?,?,?)",
                [(ids[r["station"]], r["day"], r["hour"], r["pm25"], r["pm10"], r["no2"], r["temp"])
                 for r in rows])
con.commit()
print("Rows stored:", con.execute("SELECT COUNT(*) FROM readings").fetchone()[0])

print("\n=== THE THREE QUESTIONS OF THE BOARD (SQL) ===")
q1 = con.execute("""SELECT ROUND(AVG(pm25),2) FROM readings r JOIN stations s USING (station_id)
                    WHERE s.name = ? AND r.day BETWEEN '2026-10-01' AND '2026-10-31'""", ("Adyar",)).fetchone()[0]
print("Q1  Average PM2.5 of Adyar in October          :", q1)
q2 = con.execute("""SELECT s.name, ROUND(AVG(pm25),2) a FROM readings r JOIN stations s USING (station_id)
                    GROUP BY s.name ORDER BY a DESC""").fetchall()
print("Q2  Stations ranked by October average PM2.5   :", q2)
q3 = con.execute("""SELECT COUNT(*) FROM (SELECT r.day, AVG(pm25) m FROM readings r
                    JOIN stations s USING (station_id) WHERE s.name = ?
                    GROUP BY r.day HAVING m > 60)""", ("Guindy",)).fetchone()[0]
print("Q3  Days with Guindy daily mean PM2.5 above 60 :", q3, "of 31")

# ---------------- B1.4  charts ----------------
daily = con.execute("""SELECT CAST(substr(day,9,2) AS INTEGER), AVG(pm25) FROM readings r
                       JOIN stations s USING (station_id) WHERE s.name='Adyar'
                       GROUP BY day ORDER BY day""").fetchall()
plt.figure(figsize=(6, 3.4)); plt.plot([d for d, _ in daily], [v for _, v in daily], marker="o", color="#1f77b4")
plt.title("Adyar - daily mean PM2.5, October 2026"); plt.xlabel("Day of October"); plt.ylabel("PM2.5 (ug/m3)")
plt.grid(alpha=.3); plt.tight_layout(); plt.savefig("chart1_trend.png", dpi=130); plt.close()
first, last = daily[0][1], daily[-1][1]
print("\nChart 1 (line)    : day 1 mean = %.1f, day 31 mean = %.1f, change = %+.1f" % (first, last, last - first))

plt.figure(figsize=(6, 3.4)); plt.bar([n for n, _ in q2], [v for _, v in q2], color=["#d62728", "#ff7f0e", "#2ca02c", "#1f77b4"])
plt.title("Station comparison - October mean PM2.5"); plt.xlabel("Station"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("chart2_stations.png", dpi=130); plt.close()
print("Chart 2 (bar)     :", q2)

pts = con.execute("""SELECT temp_c, pm25 FROM readings r JOIN stations s USING (station_id)
                     WHERE s.name='Adyar'""").fetchall()
t, p = [a for a, _ in pts], [b for _, b in pts]
corr = statistics.correlation(t, p)
plt.figure(figsize=(6, 3.4)); plt.scatter(t, p, s=6, alpha=.5, color="#9467bd")
plt.title("Adyar - temperature vs PM2.5 (hourly)"); plt.xlabel("Temperature (deg C)"); plt.ylabel("PM2.5 (ug/m3)")
plt.grid(alpha=.3); plt.tight_layout(); plt.savefig("chart3_scatter.png", dpi=130); plt.close()
print("Chart 3 (scatter) : correlation coefficient r = %.2f over %d points" % (corr, len(pts)))

byhour = con.execute("SELECT hour, AVG(pm25) FROM readings GROUP BY hour ORDER BY hour").fetchall()
plt.figure(figsize=(6, 3.4)); plt.bar([h for h, _ in byhour], [v for _, v in byhour], color="#8c564b")
plt.title("Mean PM2.5 by hour of day (all stations)"); plt.xlabel("Hour of day (0-23)"); plt.ylabel("PM2.5 (ug/m3)")
plt.tight_layout(); plt.savefig("chart4_hours.png", dpi=130); plt.close()
worst = sorted(byhour, key=lambda x: -x[1])[:3]; best = min(byhour, key=lambda x: x[1])
print("Chart 4 (bar)     : worst hours", [(h, round(v, 1)) for h, v in worst], "| best hour", (best[0], round(best[1], 1)))
con.close()
