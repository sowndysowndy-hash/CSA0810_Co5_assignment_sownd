import csv, io, random, time, tracemalloc
import pandas as pd

def make_csv(n):
    random.seed(1)
    out = ["station,date,pm25"]
    names = ["Adyar", "Guindy", "Velachery", "Manali"]
    for i in range(n):
        x = random.random()
        v = ("NA" if x < 0.03 else "" if x < 0.05 else str(-random.randint(1, 20)) if x < 0.06
             else "5000" if x < 0.07 else str(random.randint(10, 300)))
        out.append(f"{names[i % 4]},2026-10-{i % 28 + 1:02d},{v}")
    return "\n".join(out) + "\n"

def clean_loops(text):
    rows = []
    for r in csv.DictReader(io.StringIO(text)):
        v = r["pm25"].strip()
        if v == "" or v.upper() == "NA":
            continue
        x = float(v)
        if x < 0 or x > 999:
            continue
        rows.append((r["station"], r["date"], x))
    vals = [x for _, _, x in rows]
    lo, hi = min(vals), max(vals)
    return len(rows), [round((v - lo) / (hi - lo), 3) for v in vals]

def clean_pandas(text):
    df = pd.read_csv(io.StringIO(text), na_values=["NA"])
    df["pm25"] = df["pm25"].where(df["pm25"].between(0, 999))
    df = df.dropna(subset=["pm25"])
    df["norm"] = ((df["pm25"] - df["pm25"].min()) / (df["pm25"].max() - df["pm25"].min())).round(3)
    return len(df), df["norm"].tolist()

def best_time(fn, text, repeats):
    best = 1e9
    for _ in range(repeats):
        t = time.perf_counter(); fn(text); best = min(best, time.perf_counter() - t)
    return best

def peak_mb(fn, text):
    tracemalloc.start(); fn(text)
    peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    return peak / 1e6

print(f"{'rows':>10} {'loops (s)':>10} {'pandas (s)':>11} {'speed-up':>9} {'loops MB':>9} {'pandas MB':>10}  same result")
for n, reps in [(1_000, 5), (100_000, 3), (1_000_000, 1)]:
    text = make_csv(n)
    a, b = clean_loops(text), clean_pandas(text)
    tl, tp = best_time(clean_loops, text, reps), best_time(clean_pandas, text, reps)
    ml, mp = peak_mb(clean_loops, text), peak_mb(clean_pandas, text)
    print(f"{n:>10,} {tl:>10.4f} {tp:>11.4f} {tl / tp:>8.1f}x {ml:>9.1f} {mp:>10.1f}  {a == b}")
