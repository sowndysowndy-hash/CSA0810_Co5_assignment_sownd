import io, random, sqlite3, time
from datetime import date, timedelta
import pandas as pd

DAYS = [(date(2026, 1, 1) + timedelta(days=d)).isoformat() for d in range(365)]
random.seed(5)
rows = [(f"S{s + 1:03d}", DAYS[h // 24], h % 24, round(random.gauss(70, 25) % 400, 1))
        for s in range(120) for h in range(8760)]
print("Rows:", f"{len(rows):,}", "(120 stations x 8,760 hourly readings)")

con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?,?,?,?)", rows); con.commit()

Q = "SELECT AVG(pm25) FROM aq WHERE station = ? AND day BETWEEN ? AND ?"
params = [(f"S{random.randint(1, 120):03d}", "2026-10-01", "2026-10-31") for _ in range(100)]

def run_queries():
    t = time.perf_counter()
    for p in params:
        con.execute(Q, p).fetchone()
    return (time.perf_counter() - t) / len(params) * 1000          # ms per query

def size_mb():
    return con.execute("PRAGMA page_count").fetchone()[0] * con.execute("PRAGMA page_size").fetchone()[0] / 1e6

print("\nQuery: average PM2.5 of one station in October")
plan = lambda: con.execute("EXPLAIN QUERY PLAN " + Q, params[0]).fetchall()[0][3]
before_ms, before_size = run_queries(), size_mb()
print("Plan BEFORE index :", plan())
t = time.perf_counter(); con.execute("CREATE INDEX idx_station_day ON aq (station, day)"); build = time.perf_counter() - t
after_ms, after_size = run_queries(), size_mb()
print("Plan AFTER index  :", plan())
print(f"\n{'':22}{'no index':>12}{'with index':>12}")
print(f"{'time per query (ms)':22}{before_ms:>12.3f}{after_ms:>12.3f}")
print(f"{'database size (MB)':22}{before_size:>12.1f}{after_size:>12.1f}")
print(f"Speed-up: {before_ms / after_ms:.0f}x   | index build time: {build:.2f} s")

# the same question answered the CSV way: read the whole file into pandas every time
buf = io.StringIO(); pd.DataFrame(rows, columns=["station", "date", "hour", "pm25"]).to_csv(buf, index=False)
csv_text = buf.getvalue()
t = time.perf_counter()
df = pd.read_csv(io.StringIO(csv_text))
ans = df[(df.station == params[0][0]) & (df.date.between("2026-10-01", "2026-10-31"))].pm25.mean()
csv_ms = (time.perf_counter() - t) * 1000
print(f"\nSame question from the CSV (read_csv + filter, {len(csv_text) / 1e6:.0f} MB file): {csv_ms:.0f} ms per question")
print(f"CSV approach is {csv_ms / after_ms:,.0f}x slower than the indexed SQL query")
print(f"Both give the same answer: {abs(ans - con.execute(Q, params[0]).fetchone()[0]) < 1e-9}")

# projection for the new network
new = 100 * 96 * 365
print(f"\nNew stations: 100 x 96 readings/day x 365 = {new:,} rows per year (plus {12 * 8760:,} from the old network)")
