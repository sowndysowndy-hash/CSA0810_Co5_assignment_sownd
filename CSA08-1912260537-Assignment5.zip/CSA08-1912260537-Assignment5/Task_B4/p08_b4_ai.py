import re, time
from collections import Counter

POSITIVE = {"good", "clean", "fast", "helpful", "improved"}
NEGATIVE = {"bad", "dirty", "slow", "rude", "smoke", "broken"}
NEGATORS = {"not", "never", "no"}

def score(text):
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE else -1 if w in NEGATIVE else 0
        if i > 0 and words[i - 1] in NEGATORS:
            v = -v
        total += v
    return total

def label(text):
    s = score(text)
    return "positive" if s > 0 else "negative" if s < 0 else "neutral"

# (complaint, my own label, key word that names the main issue)
C = [
 ("The bus service is slow. Drivers are rude to senior citizens. Please improve the late night routes.", "negative", "bus"),
 ("Children in our lane are coughing every evening. Smoke from the brick kiln near Manali covers our street. The air is bad.", "negative", "kiln"),
 ("I called the helpline twice. Nobody picked up. The service is slow and the staff were not helpful.", "negative", "helpline"),
 ("Garbage is burnt on the roadside near Guindy every night. The smoke is unbearable.", "negative", "garbage"),
 ("Nobody sprinkles water on the road. Our house stays dirty all day. The dust from the metro construction is terrible.", "negative", "dust"),
 ("Air quality monitor at Velachery is broken for a week. The display shows nothing.", "negative", "monitor"),
 ("The complaint app crashes whenever I upload a photo. Support replied after five days.", "negative", "app"),
 ("The noise and fumes are awful from six in the morning. Factory trucks block our lane every day.", "negative", "trucks"),
 ("Water tanker sprinkling was promised but never done. The officials are rude when asked.", "negative", "sprinkling"),
 ("The pollution board website is slow and confusing. I could not find today's PM2.5 reading.", "negative", "website"),
 ("Nobody takes action every winter. Burning of crop waste at the city edge makes the smoke worse.", "negative", "crop"),
 ("The new bus shelter is dirty and the bins are broken. Cleaning staff never come.", "negative", "shelter"),
 ("Our flats shake at night. Generator noise from the mall is horrible. Diesel smoke enters our rooms.", "negative", "generator"),
 ("Readings on the app do not match the sensor on our street. The data looks wrong.", "negative", "readings"),
 ("Open burning behind the school continues. Complaint was closed without any visit.", "negative", "burning"),
 ("The metro feeder bus is not good for office hours. It is slow and always full.", "negative", "feeder"),
 ("Road sweeping raises more dust than it removes. The machine is bad and the operators are rude.", "negative", "sweeping"),
 ("The pollution hotline was not fast and the officer was not helpful at all.", "negative", "hotline"),
 ("We cannot sleep at night. Chemical smell from the factory is terrible.", "negative", "chemical"),
 ("Autorickshaws with old engines are polluting Adyar. The smoke they release is thick.", "negative", "autorickshaws"),
 ("No action was taken on my last complaint. It is a slow and useless process.", "negative", "action"),
 ("Nobody repairs it. The air purifier at the bus stop is broken again.", "negative", "purifier"),
 ("Streetlights are fine but the burning of plastic near the canal makes the smoke terrible.", "negative", "plastic"),
 ("Honestly the board does great work. Oh sure, a clean report every month while the air stays bad.", "negative", "report"),
 ("The new electric buses are clean and fast. Drivers are helpful. Service improved a lot.", "positive", "buses"),
 ("Thank you for the quick action on the garbage burning. The street is clean now.", "positive", "garbage"),
 ("The helpline officer was helpful and polite. My complaint was resolved in two days.", "positive", "helpline"),
 ("Dust levels near the metro site improved after water sprinkling started. Good work.", "positive", "dust"),
 ("The air monitor display is now working and the app is fast. Readings look correct.", "positive", "monitor"),
 ("The park near Guindy is clean and the air feels better. Thanks for planting trees.", "positive", "park"),
 ("Bus frequency improved on route 21. The new buses are not crowded.", "positive", "frequency"),
 ("The officer visited the factory the same day. Smoke stopped and the area is good again.", "positive", "factory"),
 ("The new website is easy to use. I found the PM2.5 reading for Adyar quickly.", "positive", "website"),
 ("Waste collection is regular and the roads are clean. Not a single missed day this month.", "positive", "collection"),
 ("Metro service is excellent. Trains are on time and the stations are clean.", "positive", "metro"),
 ("I am happy with the response. The team was helpful and the app is fast.", "positive", "response"),
 ("The sensor repair at Manali was done quickly. It is no longer broken.", "positive", "sensor"),
 ("Trees planted along the highway have improved the street a lot. It feels cleaner.", "positive", "trees"),
 ("Please share the PM2.5 level of Velachery for last week. I need it for a school project.", "neutral", "pm2.5"),
 ("When will the new monitoring station in Manali start working? The board mentioned it last month.", "neutral", "station"),
 ("Kindly confirm the office timing of the pollution board. I want to submit a form.", "neutral", "timing"),
 ("The bus was fast but the driver was rude. Overall an average ride.", "neutral", "bus"),
 ("Roads are clean near the market but the smoke from the tea stalls is irritating. Mixed feelings.", "neutral", "market"),
 ("The helpline is helpful but slow. I waited ten minutes.", "neutral", "helpline"),
 ("Is there any app to track air quality in real time? A friend said there is one.", "neutral", "app"),
 ("I want to join the tree plantation drive next Sunday. Where should I register?", "neutral", "plantation"),
 ("Is the smoke from the festival fireworks going to affect Adyar? Please advise.", "neutral", "fireworks"),
 ("Not bad. The sweeping machine works and the dust is less, but the noise is still high.", "neutral", "sweeping"),
 ("Please send the monthly air quality report for Guindy. I need it before Friday.", "neutral", "report"),
 ("The service is not good and not bad. It is just okay.", "neutral", "service"),
]
assert len(C) == 50

# ---------------- B4.1a sentiment agreement ----------------
agree, wrong = 0, []
conf = Counter()
for text, mine, _ in C:
    got = label(text)
    conf[(mine, got)] += 1
    if got == mine: agree += 1
    else: wrong.append((mine, got, text))
print("=== B4.1 SENTIMENT SCORER vs MY OWN READING (50 complaints) ===")
print(f"Agreement: {agree} of {len(C)} = {100 * agree / len(C):.0f}%")
print(f"{'my label':10}{'positive':>10}{'negative':>10}{'neutral':>9}   (columns = scorer output)")
for m in ("positive", "negative", "neutral"):
    print(f"{m:10}{conf[(m, 'positive')]:>10}{conf[(m, 'negative')]:>10}{conf[(m, 'neutral')]:>9}")
print("\nFirst five disagreements:")
for mine, got, text in wrong[:5]:
    print(f"  mine={mine:8} scorer={got:8} | {text[:70]}")

# ---------------- B4.1b extractive summariser vs first-k ----------------
STOP = set("the a an is are was were to of in on at for and or but it its this that with from by be as i we our my "
           "you your have has had not no do does did will would can could please when what where which who so very "
           "every any all there their they them he she his her than then also just only into over after before".split())
def sentences(t): return [s.strip() for s in re.split(r"(?<=[.?!])\s+", t) if s.strip()]
def words_of(s): return [w for w in re.findall(r"[a-z0-9.]+", s.lower()) if w not in STOP and len(w) > 2]

freq = Counter(w for text, _, _ in C for w in set(words_of(text)))        # corpus word frequency
def summarise(text, k=1):
    sents = sentences(text)
    def sc(s):
        ws = set(words_of(s))
        return sum(freq[w] for w in ws) / (len(ws) or 1)
    top = sorted(range(len(sents)), key=lambda i: -sc(sents[i]))[:k]
    return " ".join(sents[i] for i in sorted(top))
def first_k(text, k=1): return " ".join(sentences(text)[:k])

print("\n=== B4.1 SUMMARISER: does the summary contain the key issue word? ===")
for k in (1, 2):
    a = sum(key in summarise(t, k).lower() for t, _, key in C)
    b = sum(key in first_k(t, k).lower() for t, _, key in C)
    print(f"k = {k}:  most-frequent-words summariser {a:>2}/50   first-k baseline {b:>2}/50")
print("\nExample (complaint 2):")
print("  full    :", C[1][0]); print("  summary :", summarise(C[1][0])); print("  first-1 :", first_k(C[1][0]))
print("Example (complaint 13):")
print("  full    :", C[12][0]); print("  summary :", summarise(C[12][0])); print("  first-1 :", first_k(C[12][0]))

# ---------------- time per complaint ----------------
N = 2000
t = time.perf_counter()
for _ in range(N):
    for text, _, _ in C: score(text)
ts = (time.perf_counter() - t) / (N * 50)
t = time.perf_counter()
for _ in range(N // 10):
    for text, _, _ in C: summarise(text)
tsum = (time.perf_counter() - t) / ((N // 10) * 50)
t = time.perf_counter()
for _ in range(N):
    for text, _, _ in C: first_k(text)
tfk = (time.perf_counter() - t) / (N * 50)
print(f"\nTime per complaint: scorer {ts * 1e6:.1f} us | frequency summariser {tsum * 1e6:.1f} us | first-k {tfk * 1e6:.1f} us")
print(f"50,000 complaints a month -> scorer {ts * 50000:.2f} s, summariser {tsum * 50000:.2f} s")
