import csv, io, random, sqlite3, statistics, time, tracemalloc, cProfile, pstats
from datetime import date, timedelta
import pandas as pd

DAYS = [(date(2026, 1, 1) + timedelta(days=d)).isoformat() for d in range(365)]

def make_csv(stations, hours=8760, seed=3):
    random.seed(seed)
    out = ["station,date,hour,pm25"]
    for s in range(stations):
        name = f"S{s + 1:03d}"
        for h in range(hours):
            out.append(f"{name},{DAYS[h // 24]},{h % 24},{round(random.gauss(70, 25) % 400, 1)}")
    return "\n".join(out) + "\n"

def by_loops(text):
    groups = {}
    for r in csv.DictReader(io.StringIO(text)):
        groups.setdefault((r["station"], r["date"]), []).append(float(r["pm25"]))
    return {k: statistics.mean(v) for k, v in groups.items()}

def by_pandas(text):
    df = pd.read_csv(io.StringIO(text))
    return df.groupby(["station", "date"])["pm25"].mean().to_dict()

def sql_load(text):
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE r (station TEXT, day TEXT, hour INTEGER, pm25 REAL)")
    rd = csv.reader(io.StringIO(text)); next(rd)
    con.executemany("INSERT INTO r VALUES (?,?,?,?)", ((a, b, int(c), float(d)) for a, b, c, d in rd))
    return con

def sql_query(con):
    return {(s, d): m for s, d, m in con.execute("SELECT station, day, AVG(pm25) FROM r GROUP BY station, day")}

def by_running(text):
    acc = {}
    for r in csv.DictReader(io.StringIO(text)):
        k = (r["station"], r["date"]); a = acc.get(k)
        if a is None: acc[k] = [float(r["pm25"]), 1]
        else: a[0] += float(r["pm25"]); a[1] += 1
    return {k: t / c for k, (t, c) in acc.items()}

def same(a, b):
    return a.keys() == b.keys() and max(abs(a[k] - b[k]) for k in a) < 1e-9

# ---- B3.1 correctness on small data (1 station, 3 days) ----
small = make_csv(1, hours=72)
m1, m2 = by_loops(small), by_pandas(small)
con = sql_load(small); m3 = sql_query(con)
print("=== B3.1 CORRECTNESS (1 station, 3 days, 72 readings) ===")
print(f"{'station/day':18} {'loops':>9} {'pandas':>9} {'SQL':>9}")
for k in sorted(m1):
    print(f"{k[0] + ' ' + k[1]:18} {m1[k]:9.3f} {m2[k]:9.3f} {m3[k]:9.3f}")
print("All three agree:", same(m1, m2) and same(m1, m3))

# ---- B3.2 timing at three sizes ----
print("\n=== B3.2 TIME vs DATA SIZE (seconds) ===")
print(f"{'stations':>8} {'readings':>10} {'loops':>8} {'pandas':>8} {'SQL load':>9} {'SQL query':>10} {'SQL total':>10}  agree")
texts = {}
for n in (1, 12, 120):
    text = make_csv(n); texts[n] = text
    t = time.perf_counter(); a = by_loops(text); tl = time.perf_counter() - t
    t = time.perf_counter(); b = by_pandas(text); tp = time.perf_counter() - t
    t = time.perf_counter(); con = sql_load(text); tload = time.perf_counter() - t
    t = time.perf_counter(); c = sql_query(con); tq = time.perf_counter() - t
    print(f"{n:>8} {n * 8760:>10,} {tl:>8.3f} {tp:>8.3f} {tload:>9.3f} {tq:>10.3f} {tload + tq:>10.3f}  {same(a, b) and same(a, c)}")

# ---- B3.3 profile the plain-Python version (12 stations) ----
print("\n=== B3.3 cProfile of by_loops (12 stations, 105,120 readings) ===")
pr = cProfile.Profile(); pr.enable(); by_loops(texts[12]); pr.disable()
stats = pstats.Stats(pr).stats
rows = sorted(stats.items(), key=lambda kv: -kv[1][2])[:6]
total = sum(v[2] for v in stats.values())
print(f"{'function':38} {'calls':>9} {'own time':>9} {'cumulative':>11} {'% own':>6}")
for (fn, line, name), (cc, nc, tt, ct, _) in rows:
    short = fn.split('/')[-1] + ":" + name
    print(f"{short[:38]:38} {nc:>9,} {tt:>9.3f} {ct:>11.3f} {100 * tt / total:>5.1f}%")

# ---- alternative: running sum and count ----
print("\n=== ALTERNATIVE: one pass with running sum and count (12 stations) ===")
def peak(fn, text):
    tracemalloc.start(); fn(text); p = tracemalloc.get_traced_memory()[1]; tracemalloc.stop(); return p / 1e6
for name, fn in (("store all + statistics.mean", by_loops), ("running sum and count", by_running)):
    t = time.perf_counter(); r = fn(texts[12]); el = time.perf_counter() - t
    print(f"{name:28} time {el:6.3f} s   peak memory {peak(fn, texts[12]):6.1f} MB")
print("Same answers:", same(by_loops(texts[12]), by_running(texts[12])))
