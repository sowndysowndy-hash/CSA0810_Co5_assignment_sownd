import csv, io, os, sqlite3, tempfile, time

tmp = tempfile.mkdtemp()
def write(name, data, mode="w", **kw):
    p = os.path.join(tmp, name)
    with open(p, mode, **kw) as f:
        f.write(data)
    return p

# ---------- 1. adversarial files ----------
files = {
    "missing column":  write("a.csv", "station,date\nAdyar,2026-10-01\n"),
    "wrong delimiter": write("b.csv", "station;date;pm25\nAdyar;2026-10-01;48\n"),
    "other encoding":  write("c.csv", "station,date,pm25\nAdyar,2026-10-01,48\n", "w", encoding="utf-16"),
    "empty file":      write("d.csv", ""),
}

def naive_load(path):
    with open(path) as f:
        return [(r["station"], r["date"], float(r["pm25"])) for r in csv.DictReader(f)]

def safe_load(path):
    raw = open(path, "rb").read()
    if not raw.strip():
        raise ValueError("file is empty")
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            text = raw.decode(enc); break
        except UnicodeError:
            continue
    delim = csv.Sniffer().sniff(text.splitlines()[0], delimiters=",;\t|").delimiter
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    need = {"station", "date", "pm25"}
    if not need <= set(reader.fieldnames or []):
        raise ValueError(f"missing column(s): {sorted(need - set(reader.fieldnames or []))}")
    return [(r["station"], r["date"], float(r["pm25"])) for r in reader]

print("=== 1. ADVERSARIAL FILES ===")
for label, path in files.items():
    for name, fn in (("naive", naive_load), ("safe ", safe_load)):
        try:
            print(f"{label:16} {name} -> {fn(path)}")
        except Exception as e:
            print(f"{label:16} {name} -> {type(e).__name__}: {e}")

# ---------- 2. quote character in a station name ----------
con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
con.executemany("INSERT INTO aq VALUES (?,?,?)",
                [("Adyar", "2026-10-01", 48.0), ("Guindy", "2026-10-01", 95.0), ("St. Mary's", "2026-10-01", 70.0)])
print("\n=== 2. QUOTE CHARACTER IN SQL ===")
for name in ["St. Mary's", "Adyar' OR '1'='1"]:
    sql = "SELECT AVG(pm25) FROM aq WHERE station = '" + name + "'"
    try:
        print(f"concatenated  {name!r:22} -> {con.execute(sql).fetchone()[0]}")
    except sqlite3.Error as e:
        print(f"concatenated  {name!r:22} -> {type(e).__name__}: {e}")
    print(f"? placeholder {name!r:22} -> {con.execute('SELECT AVG(pm25) FROM aq WHERE station = ?', (name,)).fetchone()[0]}")

# ---------- 3. sentiment scorer on tricky sentences ----------
POSITIVE = {"good", "clean", "fast", "helpful", "improved"}
NEGATIVE = {"bad", "dirty", "slow", "rude", "smoke", "broken"}
NEGATORS = {"not", "never", "no"}
def score(text):
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for i, w in enumerate(words):
        v = 1 if w in POSITIVE else -1 if w in NEGATIVE else 0
        if i > 0 and words[i - 1] in NEGATORS:
            v = -v
        total += v
    return total
def label(t):
    s = score(t); return "positive" if s > 0 else "negative" if s < 0 else "neutral"

tests = [
    ("Oh great, another broken bus. Really helpful.", "negative", "sarcasm"),
    ("Yeah, the helpline is so fast. I only waited three days.", "negative", "sarcasm"),
    ("The service is not never good.", "negative", "double negative"),
    ("I cannot say the air was not bad.", "negative", "double negative"),
    ("Roads are clean but the smoke from the factory is terrible.", "negative", "mixed opinion"),
    ("The staff were helpful but the bus was slow and dirty.", "negative", "mixed opinion"),
    ("The service is not good.", "negative", "control (simple negation)"),
]
print("\n=== 3. SENTIMENT SCORER ON TRICKY SENTENCES ===")
for text, expected, kind in tests:
    got = label(text)
    print(f"{'OK  ' if got == expected else 'FAIL'} | {kind:26} | expected {expected:8} got {got:8} | {text}")

# ---------- 4. executemany vs execute in a loop ----------
print("\n=== 4. executemany() vs execute() in a loop (in-memory, 1 commit) ===")
print(f"{'rows':>9} {'executemany (s)':>16} {'execute loop (s)':>17}")
for n in (1_000, 10_000, 100_000, 500_000):
    data = [("Adyar", "2026-10-01", float(i)) for i in range(n)]
    c = sqlite3.connect(":memory:"); c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
    t = time.perf_counter(); c.executemany("INSERT INTO aq VALUES (?,?,?)", data); c.commit(); a = time.perf_counter() - t
    c = sqlite3.connect(":memory:"); c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
    t = time.perf_counter()
    for row in data:
        c.execute("INSERT INTO aq VALUES (?,?,?)", row)
    c.commit(); b = time.perf_counter() - t
    print(f"{n:>9,} {a:>16.4f} {b:>17.4f}")
print("\nOn a disk file with a commit after every row (2,000 rows):")
path = os.path.join(tmp, "t.db"); c = sqlite3.connect(path)
c.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
t = time.perf_counter()
for i in range(2000):
    c.execute("INSERT INTO aq VALUES (?,?,?)", ("Adyar", "2026-10-01", float(i))); c.commit()
print(f"  execute + commit per row : {time.perf_counter() - t:.3f} s")
c2 = sqlite3.connect(os.path.join(tmp, "t2.db")); c2.execute("CREATE TABLE aq (station TEXT, day TEXT, pm25 REAL)")
t = time.perf_counter()
c2.executemany("INSERT INTO aq VALUES (?,?,?)", [("Adyar", "2026-10-01", float(i)) for i in range(2000)]); c2.commit()
print(f"  one executemany + commit : {time.perf_counter() - t:.3f} s")
